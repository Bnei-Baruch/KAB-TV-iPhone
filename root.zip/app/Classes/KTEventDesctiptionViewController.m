    //
//  KTEventDesctiptionViewController.m
//  KabTV
//
//  Created by Leonid on 14.03.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "KTEventDesctiptionViewController.h"
#import "OrientationsController.h"
#import "GTMNSString+HTML.h"

#define HTML_TEXT @"<body style=\"background-color:#1c1d22;color:white;font:14px Helvetica\"><div style=\"width:100%;font:20px Helvetica;text-align:center;\"> {start_date} </div><div> {time} </div><div> <b> {summary} </b> </div><div> {description} </div></body>"
/*
 Страница деталей:
 Добавляем вверху 
 - Дату размером как на полели даты со стрелками 
 - Время начала и конца 
 - SUMMARY болдом - размер текста как в списке 
 - DESCRIPTION не болдом но такоже размера как SUMMARY
 
 Фон полосатый сложно добавлять ? 
 */

@interface KTEventDesctiptionViewController (hidden) <UIWebViewDelegate>

@end


@implementation KTEventDesctiptionViewController

@synthesize item=item_;


- (void)viewDidLoad
{
    [super viewDidLoad];
	
	[self.view setBackgroundColor:[UIColor colorWithRed:0.11f green:0.114f blue:0.133f alpha:1]];
	
	UIWebView* webView = [[[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.width)] autorelease];
	[webView setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
	 UIViewAutoresizingFlexibleHeight];
	[webView setDelegate:self];
	[webView setHidden:YES];
	[webView setBackgroundColor:[UIColor colorWithRed:0.11f green:0.114f blue:0.133f alpha:1]];
	[self.view addSubview:webView];
	
	NSDateFormatter* formatter = [[[NSDateFormatter alloc] init] autorelease];
	
	[formatter setDateFormat:@"MMMM d"];
	NSString* dateText = [formatter stringFromDate:item_.startDate];
	
	[formatter setDateFormat:@"H:mm"];
	NSString* timeText = [NSString stringWithFormat:@"%@ - %@", [formatter stringFromDate:item_.startDate], [formatter stringFromDate:item_.endDate]];
	
	NSString* resStr = HTML_TEXT;
	resStr = [resStr stringByReplacingOccurrencesOfString: @"{start_date}" withString:dateText];
	resStr = [resStr stringByReplacingOccurrencesOfString: @"{time}" withString:timeText];
	resStr = [resStr stringByReplacingOccurrencesOfString: @"{summary}" withString:item_.summary];
	resStr = [resStr stringByReplacingOccurrencesOfString: @"{description}" withString:(item_.description ? item_.description : @"")];
	[webView loadHTMLString:resStr
					baseURL:[NSURL URLWithString:@""]];
}

- (void)viewWillAppear:(BOOL)animated
{
	[[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO];
	[[OrientationsController sharedController] setSupportedOrientations:SO_UIInterfaceOrientationPortrait];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	return [[OrientationsController sharedController] shouldAutorotateToOrientation:interfaceOrientation];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	[webView setHidden:FALSE];
	[webView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
}

#pragma mark -
#pragma mark Memory management

- (id)initWithScheduleItem:(KTScheduleItem*)item
{
	if(self = [super init])
	{
		item_ = [item retain];
	}
	return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)dealloc
{
	[item_ release];
	
    [super dealloc];
}

@end
