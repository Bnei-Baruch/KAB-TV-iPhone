//
//  KTFirstFakeViewController.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import "KTFirstFakeViewController.h"
#import "SBJSON.h"


@implementation KTFirstFakeViewController

@synthesize delegate=delegate_;

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	UIImageView* imageView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Default.png"]] autorelease];
	[imageView setFrame:CGRectMake(0, -20, self.view.frame.size.width, self.view.frame.size.height + 20)];
	[imageView setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
	[self.view addSubview:imageView];
	
	flower_ = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite] autorelease];
	[flower_ setHidesWhenStopped:YES];
	[flower_ stopAnimating];
	[flower_ setAutoresizingMask:UIViewAutoresizingFlexibleLeftMargin |
	 UIViewAutoresizingFlexibleTopMargin |
	 UIViewAutoresizingFlexibleRightMargin |
	 UIViewAutoresizingFlexibleBottomMargin];
	[flower_ setCenter:CGPointMake(self.view.frame.size.width / 2.0f, self.view.frame.size.height / 2.0f)];
	[self.view addSubview:flower_];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return UIInterfaceOrientationIsPortrait(interfaceOrientation);
}

- (void)dealloc
{
    [super dealloc];
}

- (void)startLoading
{
	[NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://kaushan.com/kab/schedule/config.js"]]
								  delegate:self];
	[resultData_ release];
	resultData_ = [[NSMutableData alloc] init];
	
	[flower_ startAnimating];
}

- (void)connection:(NSURLConnection*)connection didReceiveData:(NSData*)data
{
	[resultData_ appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection*)connection
{
	NSString* str = [[[NSString alloc] initWithData:resultData_ encoding:NSASCIIStringEncoding] autorelease];
	SBJSON* json = [[[SBJSON alloc] init] autorelease];
	NSDictionary* result = [json objectWithString:str];
	
	[self performSelector:@selector(wasLoadedWithResult:) withObject:result];
	
	[resultData_ release];
	resultData_ = nil;
}

- (void)connection:(NSURLConnection*)connection didFailWithError:(NSError*)error
{
	[self performSelector:@selector(wasFailed)];
	 
	[resultData_ release];
	resultData_ = nil;
}

- (void)wasLoadedWithResult:(NSDictionary*)result
{
	[delegate_ dataWasLoaded:result];
	[flower_ stopAnimating];
}

- (void)wasFailed
{
	UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
													 message:@"Please make sure you have a WiFi or 3G connection."
													delegate:self
										   cancelButtonTitle:@"Retry"
										   otherButtonTitles:nil] autorelease];
	[alert show];
	[flower_ stopAnimating];
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	[self startLoading];
}

@end
