//
//  KTVideoPlayerController.h
//  KabTV
//
//  Copyright 2011 Leonik Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

typedef enum
{
	FadeTypeNone,
	FadeTypeVisible,
	FadeTypeHidding
}FadeType;

@protocol KTVideoPlayerControllerDelegate;

@interface KTVideoPlayerController : UIViewController
{
	NSURL* url_;
	MPMoviePlayerController* mediaPlayer_;
	
	id<KTVideoPlayerControllerDelegate> delegate_;
	
	NSTimer* fadeTimer_;
	FadeType fadeType_;
}

@property (nonatomic, retain) NSURL* url;
@property (nonatomic, assign) id<KTVideoPlayerControllerDelegate> delegate;

- (id)initWithContentURL:(NSURL*)url delegate:(id<KTVideoPlayerControllerDelegate>)delegate;
- (id)initWithMediaPlayer:(MPMoviePlayerController*) mediaPlayer delegate:(id<KTVideoPlayerControllerDelegate>)delegate;

@end

@protocol KTVideoPlayerControllerDelegate

- (void)videoPlayerWillPop:(KTVideoPlayerController*)sender;

@end

