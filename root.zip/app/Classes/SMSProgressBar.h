//
//  SMSProgressBar.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum
{
	SMSProgressBarProgressTypeNone,
	SMSProgressBarProgressTypeStep1,
	SMSProgressBarProgressTypeStep2,
	SMSProgressBarProgressTypeFinish
}SMSProgressBarProgressType;

@protocol SMSProgressBarDelegate;

@interface SMSProgressBar : UIView
{
	id<SMSProgressBarDelegate> delegate_;
	
	BOOL inProgress_;
	
	SMSProgressBarProgressType stepType_;
	NSTimer* timer_;
	
	UISlider* slider_;
}

@property (nonatomic, assign) id<SMSProgressBarDelegate> delegate;

+ (UIImage*)dummyImageOfSize:(CGSize)size;

- (void)start;
- (void)stop;
- (void)cancel;

@end

@protocol SMSProgressBarDelegate

- (void)progressFinished:(id)sender resultSelf:(BOOL)selfFinished;

@end

