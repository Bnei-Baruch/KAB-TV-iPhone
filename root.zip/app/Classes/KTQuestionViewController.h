//
//  KTQuestionViewController.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface KTQuestionViewController : UIViewController
{
	UIActivityIndicatorView* flower_;
	UITextView* textView_;
	UIWebView* webView_;
	
	UINavigationBar* navBar_;
	
	UIView* sendingView_;
}

@end
