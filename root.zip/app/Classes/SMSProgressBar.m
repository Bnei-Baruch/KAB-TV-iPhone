//
//  SMSProgressBar.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import "SMSProgressBar.h"

#define step 3.0
#define step2 6.0
#define score1 60.0
#define score2 100.0
#define finish 1.5


@implementation SMSProgressBar

@synthesize delegate=delegate_;

+ (UIImage*)dummyImageOfSize:(CGSize)size
{
	UIGraphicsBeginImageContext(size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [UIColor colorWithRed:0 green:0 blue:0 alpha:0].CGColor);
    CGContextFillRect(context, CGRectMake(0, 0, size.width, size.height));
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)initAll
{
	inProgress_ = FALSE;
	stepType_ = SMSProgressBarProgressTypeNone;
	
	UILabel* label = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height / 2.0f)] autorelease];
	[label setText:@"Sending..."];
	[label setTextAlignment:UITextAlignmentCenter];
	[label setTextColor:[UIColor whiteColor]];
	[label setFont:[UIFont systemFontOfSize:12]];
	[label setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
	[label setBackgroundColor:[UIColor clearColor]];
	[self addSubview:label];
	
	slider_ = [[UISlider alloc] initWithFrame:CGRectMake(0, self.frame.size.height / 2, self.frame.size.width, self.frame.size.height / 2.0f)];
	[slider_ setThumbImage:[SMSProgressBar dummyImageOfSize:CGSizeMake(1, 1)] forState:UIControlStateNormal];
	[slider_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
	[slider_ setMinimumValue:0];
	[slider_ setMaximumValue:100];
	[self addSubview:slider_];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
	{
		[self initAll];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
	{
		[self initAll];
    }
    return self;
}

- (void)start
{
	inProgress_ = YES;
	
	[slider_ release];
	
	[timer_ invalidate];
	[timer_ release];
	double duration = step / score1;
	timer_ = [[NSTimer scheduledTimerWithTimeInterval:duration
											  target:self
											selector:@selector(timerHandler:)
											userInfo:nil
											 repeats:YES] retain];
	stepType_ = SMSProgressBarProgressTypeStep1;
	
	[slider_ setValue:0];
}

- (void)stop
{
	inProgress_ = FALSE;
}

- (void)cancel
{
	[timer_ invalidate];
	[timer_ release];
	timer_ = nil;
	
	inProgress_ = FALSE;
	[delegate_ progressFinished:self resultSelf:YES];
}

- (void)timerHandler:(id)sender
{
	CGFloat val = [slider_ value];
	
	if(val >= score2)
	{
		[timer_ invalidate];
		[timer_ release];
		timer_ =nil;
		[delegate_ progressFinished:self resultSelf:(stepType_ != SMSProgressBarProgressTypeFinish)];
		return;
	}
	
	if(stepType_ == SMSProgressBarProgressTypeFinish)
	{
		[slider_ setValue:val + 1];
		return;
	}
	
	if(val < score1 && stepType_ == SMSProgressBarProgressTypeStep1)
	{
		if(inProgress_)
			[slider_ setValue:val + 1];
		else
		{
			[timer_ invalidate];
			[timer_ release];
			double duration = finish / ([slider_ maximumValue] - [slider_ value]);
			stepType_ = SMSProgressBarProgressTypeFinish;
			timer_ = [[NSTimer scheduledTimerWithTimeInterval:duration
													  target:self
													selector:@selector(timerHandler:)
													userInfo:nil
													  repeats:YES]retain];
		}
	}
	if(val >= score1 && val < score2)
	{
		if(inProgress_)
		{
			if(stepType_ == SMSProgressBarProgressTypeStep1)
			{
				[timer_ invalidate];
				[timer_ release];
				double duration = step2 / ([slider_ maximumValue] - [slider_ value]);
				stepType_ = SMSProgressBarProgressTypeStep2;
				timer_ = [[NSTimer scheduledTimerWithTimeInterval:duration
														   target:self
														 selector:@selector(timerHandler:)
														 userInfo:nil
														  repeats:YES]retain];
			}
			else if(stepType_ == SMSProgressBarProgressTypeStep2)
				[slider_ setValue:val + 1];
		}
		else
		{
			[timer_ invalidate];
			[timer_ release];
			double duration = finish / ([slider_ maximumValue] - [slider_ value]);
			stepType_ = SMSProgressBarProgressTypeFinish;
			timer_ = [[NSTimer scheduledTimerWithTimeInterval:duration
													   target:self
													 selector:@selector(timerHandler:)
													 userInfo:nil
													  repeats:YES]retain];
		}
	}
}

- (void)dealloc
{
	[timer_ invalidate];
	[timer_ release];
	
    [super dealloc];
}


@end
