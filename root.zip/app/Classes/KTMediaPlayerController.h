//
//  KTMediaPlayerController.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>

#define RUS_KEY @"rus"
#define ENG_KEY @"eng"
#define HEB_KEY @"heb"

typedef enum
{
	KTMediaPlayerControllerTypeAudio,
	KTMediaPlayerControllerTypeVideo,
}KTMediaPlayerControllerType;

@interface KTMediaPlayerController : UIViewController <AVAudioSessionDelegate>
{
	//NSURL* url_;
	NSDictionary* urls_;
	KTMediaPlayerControllerType type_;
	MPMoviePlayerController* mediaPlayer_;
	UIButton* playButton_;
	UIActivityIndicatorView* flower_;
	
	BOOL isAppear_;
	BOOL messageWasAppear_;
}

@property (nonatomic, retain) NSDictionary* urls;
@property (nonatomic) KTMediaPlayerControllerType type;

- (id)initWithContentURLs:(NSDictionary*)urls andType:(KTMediaPlayerControllerType)type;

@end
