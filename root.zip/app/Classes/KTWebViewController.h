//
//  KTWebViewController.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface KTWebViewController : UIViewController <UIWebViewDelegate>
{
	NSString* url_;
	BOOL insertNameFrom_;
	BOOL resizeText_;
	
	int scaleFactor_;
	
	UIWebView* webView_;
}

@property (nonatomic, readonly) NSString* url;
@property (nonatomic) BOOL insertNameFrom;
@property (nonatomic) BOOL resizeText;
@property (nonatomic) int scaleFactor;

- (id)initWithURLString:(NSString*)url;

@end
