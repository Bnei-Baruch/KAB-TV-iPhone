/*
 *  OrientationsController.mm
 *  Livestream
 *
 *  Copyright 2010 Gennadii Ivanov. All rights reserved.
 *
 */

#import "OrientationsController.h"

@implementation OrientationsController

static OrientationsController *_orientationsController = nil;

+ (OrientationsController*)sharedController
{
	@synchronized(self)
	{
		if (_orientationsController == nil)
		{
           _orientationsController =  [[OrientationsController alloc] init];
        }
    }
    return _orientationsController;
}

+ (void)end
{
	[_orientationsController release];
}

- (void)setSupportedOrientations:(NSInteger)orientations
{
	supportedOrientations_ = orientations;
}

- (BOOL)shouldAutorotateToOrientation:(UIInterfaceOrientation)orientation
{
	switch (orientation)
	{
		case UIInterfaceOrientationPortrait:
			return (supportedOrientations_ & SO_UIInterfaceOrientationPortrait);
			break;
		case UIInterfaceOrientationPortraitUpsideDown:
			return (supportedOrientations_ & SO_UIInterfaceOrientationPortraitUpsideDown);
			break;
		case UIInterfaceOrientationLandscapeLeft:
			return (supportedOrientations_ & SO_UIInterfaceOrientationLandscapeLeft);
			break;
		case UIInterfaceOrientationLandscapeRight:
			return (supportedOrientations_ & SO_UIInterfaceOrientationLandscapeRight);
			break;
		default:
			break;
	}
	return NO;
}

+ (NSInteger)allOrientations
{
	return (SO_UIInterfaceOrientationPortrait | SO_UIInterfaceOrientationPortraitUpsideDown | SO_UIInterfaceOrientationLandscapeLeft | SO_UIInterfaceOrientationLandscapeRight);	
}

+ (NSInteger)allOrientationsExceptPortraitUpsideDown
{
	return (SO_UIInterfaceOrientationPortrait | SO_UIInterfaceOrientationLandscapeLeft | SO_UIInterfaceOrientationLandscapeRight);	
}

+ (NSInteger)verticalOrientation
{
	return (SO_UIInterfaceOrientationPortrait | SO_UIInterfaceOrientationPortraitUpsideDown);	
}

+ (NSInteger)horizontalOrientation
{
	return (SO_UIInterfaceOrientationLandscapeLeft | SO_UIInterfaceOrientationLandscapeRight);	
}

- (void)dealloc
{
	[super dealloc];
}

@end
