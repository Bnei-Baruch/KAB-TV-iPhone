//
//  KTWebViewController.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import "KTWebViewController.h"
#import "KTSettings.h"
#import "OrientationsController.h"


@implementation KTWebViewController

@synthesize url=url_, insertNameFrom=insertNameFrom_, resizeText=resizeText_, scaleFactor=scaleFactor_;

- (id) initWithURLString:(NSString*)url
{
	if(self = [super init])
	{
		url_ = [url copy];
	}
	return self;
}

- (void)loadView
{
	// create view
	self.view = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 372)] autorelease];
	
	// create web view
	webView_ = [[[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)] autorelease];
	[webView_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
	[webView_ setDelegate:self];
	[self.view addSubview:webView_];
	[webView_ setScalesPageToFit:YES];
	
	// set nav bar buttons
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh
																							target:self
																							action:@selector(reload)] autorelease];
}

- (void)reload
{
	[webView_ loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url_]]];
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	[webView_ loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url_]]];
}

- (void)viewWillAppear:(BOOL)animated
{
	[[OrientationsController sharedController] setSupportedOrientations:SO_UIInterfaceOrientationPortrait];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	return [[OrientationsController sharedController] shouldAutorotateToOrientation:interfaceOrientation];
}

#pragma mark -
#pragma mark UIWebViewDelegate

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	// insert data
	if(insertNameFrom_)
	{
		NSString* userName = [[NSUserDefaults standardUserDefaults] objectForKey:udNameKey];
		NSString* userFrom = [[NSUserDefaults standardUserDefaults] objectForKey:udFromKey];
		NSString* js = [NSString stringWithFormat:@"%@%@",
						(userName ? [NSString stringWithFormat:@"document.getElementById('QName').value = \"%@\";", userName] : @""),
						(userFrom ? [NSString stringWithFormat:@"document.getElementById('QFrom').value = \"%@\";", userFrom] : @"")];
		[webView stringByEvaluatingJavaScriptFromString:js];
	}
	if(resizeText_)
	{
		NSString* js = @"document.getElementById('Counter').style.fontSize = '36px';document.getElementById('menu').style.fontSize = '36px';";
		[webView stringByEvaluatingJavaScriptFromString:js];
	}
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
	
	webView_ = nil;
}

- (void)dealloc
{
	[url_ release];
	
    [super dealloc];
}


@end
