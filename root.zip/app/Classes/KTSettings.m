//
//  KTSettings.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import "KTSettings.h"
#import "SBJSON.h"
#import "OrientationsController.h"

#define kNameTFTag 1234
#define kFromTFTag 1235

@interface KTSettings (hidden)

- (void)startLocation:(id)sender;

@end



@implementation KTSettings

#pragma mark -
#pragma mark Static

+ (double)latitudeRangeForLocation:(CLLocation *)aLocation
{
	const double M = 6367000.0; // approximate average meridional radius of curvature of earth
	const double metersToLatitude = 1.0 / ((M_PI / 180.0) * M);
	const double accuracyToWindowScale = 2.0;
	
	return aLocation.horizontalAccuracy * metersToLatitude * accuracyToWindowScale;
}

+ (double)longitudeRangeForLocation:(CLLocation *)aLocation
{
	double latitudeRange =
	[KTSettings latitudeRangeForLocation:aLocation];
	
	return latitudeRange * cos(aLocation.coordinate.latitude * M_PI / 180.0);
}

#pragma mark -
#pragma mark Init

- (id)init
{
	if(self = [super init])
	{
		firstAppear_ = YES;
	}
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	if(self = [super initWithCoder:aDecoder])
	{
		firstAppear_ = YES;
	}
	return self;
}

- (id)initWithStyle:(UITableViewStyle)style
{
	if(self = [super initWithStyle:style])
	{
		firstAppear_ = YES;
	}
	return self;
}

#pragma mark -
#pragma mark View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
	[[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO];
	[[OrientationsController sharedController] setSupportedOrientations:SO_UIInterfaceOrientationPortrait];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Save"
																			   style:UIBarButtonItemStyleBordered
																			  target:self
																			  action:@selector(saveTouched)] autorelease];
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Get Location"
																			  style:UIBarButtonItemStyleBordered
																			 target:self
																			 action:@selector(startLocation:)] autorelease];
	
	flower_ = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge] autorelease];
	[flower_ setHidesWhenStopped:YES];
	[flower_ stopAnimating];
	[flower_ setCenter:CGPointMake(self.view.frame.size.width / 2, self.view.frame.size.height / 2)];
	[self.view addSubview:flower_];
	
	[name_ release];
	name_ = [[[NSUserDefaults standardUserDefaults] objectForKey:udNameKey] copy];
	[from_ release];
	from_ = [[[NSUserDefaults standardUserDefaults] objectForKey:udFromKey] copy];
}

- (void)viewDidAppear:(BOOL)animated
{
	if(firstAppear_)
	{
		firstAppear_ = FALSE;
		NSString* fromString = [[NSUserDefaults standardUserDefaults] objectForKey:udFromKey];
		if(!fromString || [fromString isEqualToString:@""])
		{
			UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Location"
															 message:@"Do you want to automatically determine the location of your place?"
															delegate:self
												   cancelButtonTitle:@"NO"
												   otherButtonTitles:@"Yes", nil] autorelease];
			[alert show];
		}
	}
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	return [[OrientationsController sharedController] shouldAutorotateToOrientation:interfaceOrientation];
}

#pragma mark -
#pragma mark Methods

- (void)startLocation:(id)sender
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	[flower_ startAnimating];
	
	[locationManager_ stopUpdatingLocation];
	[locationManager_ release];
	locationManager_ = [[CLLocationManager alloc] init];
	locationManager_.delegate = self;
	[locationManager_ startUpdatingLocation];
	
	timer_ = [NSTimer scheduledTimerWithTimeInterval:60
											  target:self
											selector:@selector(failLocationTimer:)
											userInfo:nil
											 repeats:NO];
}

- (void)saveTouched
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	[[NSUserDefaults standardUserDefaults] setObject:nameTF_.text forKey:udNameKey];
	[[NSUserDefaults standardUserDefaults] setObject:fromTF_.text forKey:udFromKey];
	
	[nameTF_ resignFirstResponder];
	[fromTF_ resignFirstResponder];
}

- (void)failLocation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	[flower_ stopAnimating];
	
	UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
													 message:@"Sorry, location unable to determine. Please type your location manually."
													delegate:nil
										   cancelButtonTitle:@"OK"
										   otherButtonTitles:nil] autorelease];
	[alert show];
}

- (void)failLocationTimer:(NSNotification*)notify
{
	timer_ = nil;
	
	[locationManager_ release];
	locationManager_ = nil;
	
	[self failLocation];
}

#pragma mark -
#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	[timer_ invalidate];
	timer_ = nil;
	
	[manager stopUpdatingLocation];
	
	[responceData_ release];
	responceData_ = [[NSMutableData alloc] init];
	
	NSDictionary* coords = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[NSNumber numberWithDouble:newLocation.coordinate.latitude], [NSNumber numberWithDouble:newLocation.coordinate.longitude], nil]
													   forKeys:[NSArray arrayWithObjects:@"lat", @"lng", nil]];
	
	[self performSelectorInBackground:@selector(requestInBackgroung:)
						   withObject:coords];
}

- (void)requestInBackgroung:(NSDictionary*)coords
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	double lat = [(NSNumber*)[coords objectForKey:@"lat"] doubleValue];
	double lng = [(NSNumber*)[coords objectForKey:@"lng"] doubleValue];
	
	NSString* urlString = [NSString stringWithFormat: @"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&sensor=false&language=en", lat, lng];
	NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]
														   cachePolicy:NSURLRequestReloadIgnoringLocalCacheData 
													   timeoutInterval:60];
	[[[NSURLConnection alloc] initWithRequest:request
									 delegate:self] autorelease];
	
	[pool release];
	
	CFRunLoopRun();
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	[timer_ invalidate];
	timer_ = nil;
	
	[manager stopUpdatingLocation];
	
	[self failLocation];
}

#pragma mark -
#pragma mark NSURLConnectionDelegate

-(void)connection:(NSURLConnection*)connection didReceiveData:(NSData*)data
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	@synchronized(self)
	{
		[responceData_ appendData:data];
	}
	
	[pool release];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	NSString* str = @"";
	@synchronized(self)
	{
		str = [[[NSString alloc] initWithData:responceData_ encoding:NSUTF8StringEncoding] autorelease];
	}
	SBJSON* json = [[[SBJSON alloc] init] autorelease];
	NSDictionary* dictionaryResult = [json objectWithString:str];
	
	BOOL forBreak = FALSE;
	
	NSString* cityName = nil;
	NSString* countryName = nil;
	
	if([dictionaryResult isKindOfClass:[NSDictionary class]] && [[[dictionaryResult objectForKey:@"status"] lowercaseString] isEqualToString:@"ok"])
	{
		NSArray* results = [dictionaryResult objectForKey:@"results"];
		for (NSDictionary* itemResult in results)
		{
			NSArray* types = [itemResult objectForKey:@"types"];
			for (NSString* type in types)
			{
				if([type isEqualToString:@"locality"])
				{
					// gets locality
					
					NSArray* addressComponents = [itemResult objectForKey:@"address_components"];
					for (NSDictionary* addressComponent in addressComponents)
					{
						NSArray* comtonentTypes = [addressComponent objectForKey:@"types"];
						for (NSString* componentType in comtonentTypes)
						{
							if([componentType isEqualToString:@"locality"])
							{
								cityName = [addressComponent objectForKey:@"long_name"];
								if(countryName)
								{
									forBreak = YES;
									break;
								}
							}
							if([componentType isEqualToString:@"country"])
							{
								countryName = [addressComponent objectForKey:@"long_name"];
								if(cityName)
								{
									forBreak = YES;
									break;
								}
							}
						}
						
						if(forBreak)
							break;
					}
				}
				
				if(forBreak)
					break;
			}
			
			if(forBreak)
				break;
		}
	}
	
	if(countryName && cityName)
	{
		NSDictionary* fromDic = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:countryName, cityName, nil]
															forKeys:[NSArray arrayWithObjects:@"country", @"city", nil]];
		[self performSelectorOnMainThread:@selector(connectionDidFinishLoadingOnMain:)
							   withObject:fromDic
							waitUntilDone:YES];
	}
	else
		[self performSelectorOnMainThread:@selector(failLocation) withObject:nil waitUntilDone:YES];
	
	[pool release];
	
	CFRunLoopStop(CFRunLoopGetCurrent());
}

- (void)connectionDidFinishLoadingOnMain:(NSDictionary*)fromDic
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	[flower_ stopAnimating];
	
	[from_ release];
	from_ = [[NSString stringWithFormat:@"%@ / %@", [fromDic objectForKey:@"country"], [fromDic objectForKey:@"city"]] copy];
	
	// insert into text field
	[fromTF_ setText:from_];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSLog(@"error = %@", [error localizedDescription]);
	
	[self performSelectorOnMainThread:@selector(failLocation) withObject:nil waitUntilDone:YES];
	
	[pool release];
	
	CFRunLoopStop(CFRunLoopGetCurrent());
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if(buttonIndex == 1)
	{
		[self startLocation:nil];
	}
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return 2;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
	{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
	
	while ([[cell.contentView subviews] count] > 0)
		[[[cell.contentView subviews] objectAtIndex:0] removeFromSuperview];
    
	if(indexPath.row == 0)
	{
		// add label
		UILabel* label = [[[UILabel alloc] initWithFrame:CGRectMake(10, 0, cell.contentView.frame.size.width / 3.0f - 20, cell.contentView.frame.size.height)] autorelease];
		[label setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
		[label setFont:[UIFont systemFontOfSize:17]];
		[label setText:@"Name"];
		[label setBackgroundColor:[UIColor clearColor]];
		[cell.contentView addSubview:label];
		
		// add text field
		nameTF_ = [[[UITextField alloc] initWithFrame:CGRectMake(0, 0, cell.contentView.frame.size.width * 2.0f / 3.0f, 22.0f)] autorelease];
		[nameTF_ setTag:kNameTFTag];
		if(name_)
			[nameTF_ setText:name_];
		[nameTF_ setBorderStyle:UITextBorderStyleNone];
		[nameTF_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin];
		[nameTF_ setDelegate:self];
		[nameTF_ setPlaceholder:@"Please set tour name"];
		[nameTF_ setCenter:CGPointMake(cell.contentView.frame.size.width * 2.0f / 3.0f, cell.contentView.frame.size.height / 2.0f)];
		[cell.contentView addSubview:nameTF_];
		
		[cell setSelectionStyle:UITableViewCellSelectionStyleNone];
	}
	else if(indexPath.row == 1)
	{
		// add label
		UILabel* label = [[[UILabel alloc] initWithFrame:CGRectMake(10, 0, cell.contentView.frame.size.width / 3.0f - 20, cell.contentView.frame.size.height)] autorelease];
		[label setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
		[label setFont:[UIFont systemFontOfSize:17]];
		[label setText:@"From"];
		[label setBackgroundColor:[UIColor clearColor]];
		[cell.contentView addSubview:label];
		
		// add text field
		fromTF_ = [[[UITextField alloc] initWithFrame:CGRectMake(0, 0, cell.contentView.frame.size.width * 2.0f / 3.0f, 22.0f)] autorelease];
		[fromTF_ setTag:kFromTFTag];
		if(from_)
			[fromTF_ setText:from_];
		[fromTF_ setBorderStyle:UITextBorderStyleNone];
		[fromTF_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin];
		[fromTF_ setDelegate:self];
		[fromTF_ setPlaceholder:@"Country/City"];
		[fromTF_ setCenter:CGPointMake(cell.contentView.frame.size.width * 2.0f / 3.0f, cell.contentView.frame.size.height / 2.0f)];
		[cell.contentView addSubview:fromTF_];
		
		[cell setSelectionStyle:UITableViewCellSelectionStyleNone];
	}
    
    return cell;
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	
	if(textField == nameTF_)
	{
		[name_ release];
		name_ = [[nameTF_ text] copy];
	}
	if(textField == fromTF_)
	{
		[from_ release];
		from_ = [[fromTF_ text] copy];
	}
	
	return YES;
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
	nameTF_ = nil;
	fromTF_ = nil;
}

- (void)dealloc
{
	[from_ release];
	[name_ release];
	
	[locationManager_ release];
	locationManager_ = nil;
	[responceData_ release];
	
    [super dealloc];
}


@end

