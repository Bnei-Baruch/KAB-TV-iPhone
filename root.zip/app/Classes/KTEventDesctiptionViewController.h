//
//  KTEventDesctiptionViewController.h
//  KabTV
//
//  Created by Leonid on 14.03.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KTScheduleItem.h"


@interface KTEventDesctiptionViewController : UIViewController
{
	KTScheduleItem* item_;
}

@property (nonatomic, readonly) KTScheduleItem* item;

- (id)initWithScheduleItem:(KTScheduleItem*)item;

@end
