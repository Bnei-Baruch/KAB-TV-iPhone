//
//  KTMediaPlayerController.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import "KTMediaPlayerController.h"
#import "OrientationsController.h"
#import "KTVideoPlayerController.h"
#import "KabTVAppDelegate.h"


#define kTagPlay 1000
#define kTagPause 1001

@interface KTMediaPlayerController (hidden) <KTVideoPlayerControllerDelegate, UIActionSheetDelegate>

- (void)pauseMovie;
- (void)playMovie;

- (void)setupMediaPlayer:(NSString*)key;
- (void)removeMediaPlayer:(BOOL)fully;
- (void) setupAudioSession;

@end


@implementation KTMediaPlayerController

@synthesize urls=urls_, type=type_;

#pragma mark -
#pragma mark Rotations

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	return [[OrientationsController sharedController] shouldAutorotateToOrientation:interfaceOrientation];
}

#pragma mark -
#pragma mark Memory management

- (id)initWithContentURLs:(NSDictionary*)urls andType:(KTMediaPlayerControllerType)type
{
	if(self = [super init])
	{
		urls_ = [urls retain];
		type_ = type;
	}
	return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
	playButton_ = nil;
	
    [super viewDidUnload];
}

- (void)dealloc
{
	[self removeMediaPlayer:YES];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	
	[urls_ release];
	[mediaPlayer_ release];
	
    [super dealloc];
}

#pragma mark -
#pragma mark View lifecicle

- (void)loadView
{
	// create view
	self.view = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320.0f, 372)] autorelease];
	
	// add image
	UIImageView* backgroundImageView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Default.png"]] autorelease];
	[backgroundImageView setFrame:CGRectMake(0, -64 - 45, 320.0f, 480.0f)];
	[self.view addSubview:backgroundImageView];
	
	flower_ = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite] autorelease];
	[flower_ setCenter:CGPointMake(self.view.frame.size.width / 2.0f, self.view.frame.size.height / 2.0f)];
	[flower_ startAnimating];
	[flower_ setHidesWhenStopped:YES];
	[self.view addSubview: flower_];
}

- (void)viewWillAppear:(BOOL)animated
{
	if(type_ == KTMediaPlayerControllerTypeVideo)
	{
		[[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO];
		[self.navigationController setNavigationBarHidden:NO animated:NO];
	}
	[[OrientationsController sharedController] setSupportedOrientations:SO_UIInterfaceOrientationPortrait];
}

- (void)viewDidAppear:(BOOL)animated
{
	UIActionSheet* actionSheet = [[[UIActionSheet alloc] initWithTitle:@""
															  delegate:self
													 cancelButtonTitle:@"Cancel"
												destructiveButtonTitle:nil
													 otherButtonTitles:@"Russian", @"English", @"Hebrew", nil] autorelease];
	UIWindow* window = [(KabTVAppDelegate*)[[UIApplication sharedApplication] delegate] window];
	[actionSheet showInView:window];
	
	isAppear_ = YES;
	messageWasAppear_ = FALSE;
}

- (void)viewWillDisappear:(BOOL)animated
{
	if([[self.navigationController viewControllers] count] <= 1)
		[self removeMediaPlayer:YES];
	
	
	isAppear_ = FALSE;
	
	[[UIApplication sharedApplication] setStatusBarHidden:FALSE animated:FALSE];
	[self.navigationItem setTitle:@""];
}

#pragma mark -
#pragma mark Media player

- (void)setupMediaPlayer:(NSString*)key
{
	NSLog(@"setupMediaPlayer with key %@", key);
	
	[self removeMediaPlayer:YES];
	
	mediaPlayer_ = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL URLWithString:[urls_ objectForKey:key]]];
	
	if(type_ == KTMediaPlayerControllerTypeAudio)
	{
		//add playback button
		playButton_ = [UIButton buttonWithType:UIButtonTypeCustom];
		[playButton_ addTarget:self action:@selector(playbackButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		[playButton_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
		[playButton_ setFrame:CGRectMake(-2, 0, self.view.frame.size.width + 2, self.view.frame.size.height)];
		[playButton_ setHidden:YES];
		
		[self.view addSubview:playButton_];
		
		//load volume images
		UIImage *imagePause = [UIImage imageNamed:@"audio-pause.png"];
		UIImage *imagePlay = [UIImage imageNamed:@"audio-play.png"];
		
		//add on view
		UIImageView *viewPause = [[UIImageView alloc] initWithImage:imagePause];
		[viewPause setCenter:CGPointMake(playButton_.frame.size.width / 2.0f, playButton_.frame.size.height / 2.0f)];
		[viewPause setAutoresizingMask:UIViewAutoresizingFlexibleTopMargin |
		 UIViewAutoresizingFlexibleBottomMargin |
		 UIViewAutoresizingFlexibleLeftMargin |
		 UIViewAutoresizingFlexibleRightMargin];
		viewPause.userInteractionEnabled = NO;
		viewPause.tag = kTagPause;
		[playButton_ addSubview:viewPause];
		
		//add off view
		UIImageView *viewPlay = [[UIImageView alloc] initWithImage:imagePlay];
		[viewPlay setCenter:CGPointMake(playButton_.frame.size.width / 2.0f, playButton_.frame.size.height / 2.0f)];
		[viewPlay setAutoresizingMask:UIViewAutoresizingFlexibleTopMargin |
		 UIViewAutoresizingFlexibleBottomMargin |
		 UIViewAutoresizingFlexibleLeftMargin |
		 UIViewAutoresizingFlexibleRightMargin];
		viewPlay.userInteractionEnabled = NO;
		viewPlay.tag = kTagPlay;
		viewPlay.hidden = YES;
		[playButton_ addSubview:viewPlay];
	}	
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:mediaPlayer_];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackStateDidChange:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:mediaPlayer_];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadStateDidChange:) name:MPMoviePlayerLoadStateDidChangeNotification object:mediaPlayer_];
}

- (void)removeMediaPlayer:(BOOL)fully
{
	NSLog(@"KTMediaPlayerController::removeMediaPlayer");
	
	[playButton_ removeFromSuperview];
	playButton_ = nil;
	
	[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:mediaPlayer_];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackStateDidChangeNotification object:mediaPlayer_];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerLoadStateDidChangeNotification object:mediaPlayer_];
	
	if(fully)
	{
		[mediaPlayer_ pause];
		[mediaPlayer_ stop];
	}
	[mediaPlayer_.view removeFromSuperview];
	[mediaPlayer_ release];
	mediaPlayer_ = nil;
}

- (void) setupAudioSession
{
    AVAudioSession *mySession = [AVAudioSession sharedInstance];
	
    // Specify that this object is the delegate of the audio session, so that
    //    this object's endInterruption method will be invoked when needed.
    [mySession setDelegate: self];
	
    // Assign the Playback category to the audio session.
    NSError *audioSessionError = nil;
    [mySession setCategory: AVAudioSessionCategoryPlayback
                     error: &audioSessionError];
    
    if (audioSessionError != nil)
	{
        NSLog (@"Error setting audio session category.");
        return;
    }
    
    //[mySession setPreferredHardwareSampleRate: graphSampleRate
      //                                  error: &audioSessionError];
    
    if (audioSessionError != nil)
	{
        NSLog (@"Error setting preferred hardware sample rate.");
        return;
    }
	
    // Activate the audio session
    [mySession setActive: YES
                   error: &audioSessionError];
	
    if (audioSessionError != nil)
	{
        NSLog (@"Error activating audio session during initial setup.");
        return;
    }
}

- (void)loadStateDidChange:(NSNotification*)notification
{
	if([notification object] == mediaPlayer_)
	{
		NSLog(@"KTMediaPlayerController::loadStateDidChange %d (%@)", mediaPlayer_.loadState, (type_ == KTMediaPlayerControllerTypeAudio ? @"audio" : @"video"));
		if(mediaPlayer_.loadState & MPMovieLoadStatePlayable)// && !(mediaPlayer_.loadState & MPMovieLoadStatePlaythroughOK))
		{
			if(type_ == KTMediaPlayerControllerTypeAudio)
			{
				[flower_ stopAnimating];
				[playButton_ setHidden:FALSE];
				
				[self setupAudioSession];
			}
			else if(type_ == KTMediaPlayerControllerTypeVideo)
			{
				if(!isAppear_)
					[self pauseMovie];
				else
					[self performSelector:@selector(pushMediaPLayer) withObject:nil afterDelay:0];
			}
		}
		else
		{
			NSLog(@"SHOW_1");
			if(isAppear_ && !messageWasAppear_)
			{
				messageWasAppear_ = YES;
				
				if(type_ == KTMediaPlayerControllerTypeAudio)
				{
					[flower_ stopAnimating];
					
					UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
																	 message:@"Cant connect to audio."
																	delegate:nil
														   cancelButtonTitle:@"OK"
														   otherButtonTitles:nil] autorelease];
					[alert show];
				}
				else if(type_ == KTMediaPlayerControllerTypeVideo)
				{
					UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
																	 message:@"Cant connect to video."
																	delegate:nil
														   cancelButtonTitle:@"OK"
														   otherButtonTitles:nil] autorelease];
					[alert show];
				}
			}
			
			[self videoPlayerWillPop:nil];
		}
	}
}

- (void)pushMediaPLayer
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	
	KTVideoPlayerController* videoController = [[[KTVideoPlayerController alloc] initWithMediaPlayer:mediaPlayer_ delegate:self] autorelease];
	[self.navigationController pushViewController:videoController animated:NO];
}

- (void)playbackStateDidChange:(NSNotification*)notification
{
	if([notification object] == mediaPlayer_)
	{
		NSLog(@"KTMediaPlayerController::playbackStateDidChange %d (%@)", mediaPlayer_.playbackState, (type_ == KTMediaPlayerControllerTypeAudio ? @"audio" : @"video"));
		
		if(!isAppear_)
			[self pauseMovie];
	}
}

- (void)playbackDidFinish:(NSNotification*)notification
{
	if([notification object] == mediaPlayer_)
	{
		NSLog(@"LSMediaPlayerController::playbackDidFinish %d (%@)", mediaPlayer_.movieMediaTypes, (type_ == KTMediaPlayerControllerTypeAudio ? @"audio" : @"video"));
		NSString *reasonDescription = @"Uknown";
		NSNumber *reason = [[notification userInfo] objectForKey:@"MPMoviePlayerPlaybackDidFinishReasonUserInfoKey"];
		if (reason)
		{
			switch ([reason intValue])
			{
				case MPMovieFinishReasonPlaybackEnded:
					reasonDescription = @"MPMovieFinishReasonPlaybackEnded";
					break;
				case MPMovieFinishReasonPlaybackError:
					reasonDescription = @"MPMovieFinishReasonPlaybackError";
					
					if(isAppear_ && !messageWasAppear_)
					{
						messageWasAppear_ = YES;
						
						if(type_ == KTMediaPlayerControllerTypeAudio)
						{
							[flower_ stopAnimating];
							
							UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
																			 message:@"Cant connect to audio."
																			delegate:nil
																   cancelButtonTitle:@"OK"
																   otherButtonTitles:nil] autorelease];
							[alert show];
						}
						else if(type_ = KTMediaPlayerControllerTypeVideo)
						{
							UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
																			 message:@"Cant connect to video."
																			delegate:nil
																   cancelButtonTitle:@"OK"
																   otherButtonTitles:nil] autorelease];
							[alert show];
						}
						
						[self videoPlayerWillPop:nil];
					}
					break;
				case MPMovieFinishReasonUserExited:
					reasonDescription = @"MPMovieFinishReasonUserExited";
					break;
				default:
					break;
			}
		}
		
		NSLog(@"LSMediaPlayerController::playbackDidFinish reason = %@ (%@)", reasonDescription, (type_ == KTMediaPlayerControllerTypeAudio ? @"audio" : @"video"));
	}
}

#pragma mark -
#pragma mark MPMoviePlayer

- (void)pauseMovie
{
	[mediaPlayer_ pause];
}

- (void)playMovie
{
	[mediaPlayer_ play];
}

- (BOOL)isMoviePaused
{
	return mediaPlayer_.playbackState == MPMoviePlaybackStatePaused;
}

- (BOOL)isMoviePlaying
{
	return mediaPlayer_.playbackState == MPMoviePlaybackStatePlaying;
}

- (void)updatePlayback:(id)sender
{
	//check sender
	if ([sender isKindOfClass:[UIButton class]])
	{
		//get parent
		UIView *parent = (UIView*)sender;
		
		//check controls
		if (![parent viewWithTag:kTagPlay] || ![parent viewWithTag:kTagPause])
			return;
		
		//check new state
		if ([self isMoviePaused] ||
			[self isMoviePlaying])
		{
			//check if paused
			BOOL paused = [self isMoviePaused];
			
			//change volume images
			UIView *viewPlay = [parent viewWithTag:kTagPlay];
			viewPlay.hidden = !paused;
			UIView *viewPause = [parent viewWithTag:kTagPause];
			viewPause.hidden = paused;
		}
	}
}

- (void)playbackButtonPressed:(id)sender
{
	//change movie state
	if ([self isMoviePaused])
		[self playMovie];
	else
		[self pauseMovie];
	
	//update view
	[self updatePlayback:sender];
}

#pragma mark -
#pragma mark KTVideoPlayerControllerDelegate

- (void)videoPlayerWillPop:(KTVideoPlayerController*)sender
{
	[[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO];
	[self.navigationController setNavigationBarHidden:NO animated:NO];
	
	[self removeMediaPlayer:YES];
	[(id)[[UIApplication sharedApplication] delegate] performSelector:@selector(selectPreviousViewController)];
}

#pragma mark -
#pragma mark UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if(buttonIndex == [actionSheet cancelButtonIndex])
		[self videoPlayerWillPop:nil];
	else
	{
		if(buttonIndex == 0)
		{
			[self setupMediaPlayer:RUS_KEY];
			[self.navigationItem setTitle:@"Russian"];
		}
		if(buttonIndex == 1)
		{
			[self setupMediaPlayer:ENG_KEY];
			[self.navigationItem setTitle:@"English"];
		}
		if(buttonIndex == 2)
		{
			[self setupMediaPlayer:HEB_KEY];
			[self.navigationItem setTitle:@"Hebrew"];
		}
		
		[flower_ startAnimating];
		[self playMovie];
	}
}

@end
