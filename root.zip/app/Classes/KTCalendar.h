//
//  KTCalendar.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface KTCalendar : UIViewController
{
	UIView* headerContainer_;
	UITableView* eventsTable_;
	UIActivityIndicatorView* flower_;
	UIScrollView* headerScrollView_;
	
	NSMutableDictionary* events_;
	//NSString* selectedKey_;
	int selectedIndex_;
	int previousSelectedIndex_;
	NSMutableArray* sortedKeys_;
}

@end
