//
//  KabTVAppDelegate.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import "KabTVAppDelegate.h"
#import "KTSettings.h"
#import "KTWebViewController.h"
#import "KTQuestionViewController.h"
#import "KTMediaPlayerController.h"
#import "KTCalendar.h"
#import "KTScheduleItem.h"

@interface KabTVAppDelegate (hidden) <UITabBarControllerDelegate, KTFirstFakeViewControllerDelegate>

@end


@implementation KabTVAppDelegate

@synthesize window;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	NSBundle *pluginBundle = [NSBundle bundleForClass: [KTScheduleItem class]];
	NSString *zoneinfoPath = [NSString stringWithFormat: @"%@/zoneinfo", [pluginBundle resourcePath]];
	set_zone_directory((char*)[zoneinfoPath cStringUsingEncoding:NSASCIIStringEncoding]);	
	
	firstViewController_ = [[KTFirstFakeViewController alloc] init];
	[firstViewController_ setDelegate:self];
	[self.window addSubview:firstViewController_.view];
	[firstViewController_ startLoading];
    
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)dataWasLoaded:(NSDictionary*)urls
{
	[firstViewController_.view removeFromSuperview];
	[firstViewController_ release];
	firstViewController_ = nil;
	
	// create array for tab bar
	NSMutableArray* viewControllers = [NSMutableArray array];
	
	// create tab bar
	tabBarController_ = [[UITabBarController alloc] init];
	//[tabBarController_ setHidesBottomBarWhenPushed:YES];
	
	// create 1-st web view
	KTCalendar* scheduleViewController = [[[KTCalendar alloc] init] autorelease];
	UITabBarItem* scheduleTabBarItem = [[[UITabBarItem alloc] initWithTitle:@"Schedule"
																	  image:[UIImage imageNamed:@"Schedule.png"]
																		tag:1] autorelease];
	scheduleViewController.tabBarItem = scheduleTabBarItem;
	UINavigationController* scheduleNavController = [[[UINavigationController alloc] initWithRootViewController:scheduleViewController] autorelease];
	[viewControllers addObject:scheduleNavController];
	
	previouSelectedViewController_ = 0;
	
	KTQuestionViewController* questionViewController = [[[KTQuestionViewController alloc] init] autorelease];
	UITabBarItem* questionTabBarItem = [[[UITabBarItem alloc] initWithTitle:@"Ask Question"
																	  image:[UIImage imageNamed:@"Feedback.png"]
																		tag:2] autorelease];
	questionViewController.tabBarItem = questionTabBarItem;
	UINavigationController* questionNavController = [[[UINavigationController alloc] initWithRootViewController:questionViewController] autorelease];
	[viewControllers addObject:questionNavController];
	
	// create audio controller
	/*NSDictionary* aUrls = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[NSURL URLWithString:@"http://kabbala.fm:8000/ices4.mp3"], [NSURL URLWithString:@"http://kabbala.fm:8000/ices5.mp3"], [NSURL URLWithString:@"http://kabbala.fm:8000/ices7.mp3"], nil]
													  forKeys:[NSArray arrayWithObjects:RUS_KEY, ENG_KEY, HEB_KEY, nil]];*/
	NSDictionary* aUrls = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[urls objectForKey:@"aud_rus"], [urls objectForKey:@"aud_eng"], [urls objectForKey:@"aud_heb"], nil]
													  forKeys:[NSArray arrayWithObjects:RUS_KEY, ENG_KEY, HEB_KEY, nil]];
	KTMediaPlayerController* audioController = [[[KTMediaPlayerController alloc] initWithContentURLs:aUrls
																							 andType:KTMediaPlayerControllerTypeAudio] autorelease];
	UITabBarItem* audioTabBarItem = [[[UITabBarItem alloc] initWithTitle:@"Audio"
																   image:[UIImage imageNamed:@"Music.png"]
																	 tag:3] autorelease];
	audioController.tabBarItem = audioTabBarItem;
	UINavigationController* audioNavigationController = [[[UINavigationController alloc] initWithRootViewController:audioController] autorelease];
	[viewControllers addObject:audioNavigationController];
	
	// create video controller
	// http://flash3.eu.kab.tv:1935/liverus/mobile.sdp/playlist.m3u8
	/*NSDictionary* vUrls = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[NSURL URLWithString:@"http://flash3.eu.kab.tv:1935/liverus/mobile.sdp/playlist.m3u8"], [NSURL URLWithString:@"http://flash3.eu.kab.tv:1935/live/mobile.sdp/playlist.m3u8"], [NSURL URLWithString:@"http://flash3.eu.kab.tv:1935/liveheb/mobile.sdp/playlist.m3u8"], nil]
													  forKeys:[NSArray arrayWithObjects:RUS_KEY, ENG_KEY, HEB_KEY, nil]];*/
	NSDictionary* vUrls = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[urls objectForKey:@"vid_rus"], [urls objectForKey:@"vid_eng"], [urls objectForKey:@"vid_heb"], nil]
													  forKeys:[NSArray arrayWithObjects:RUS_KEY, ENG_KEY, HEB_KEY, nil]];
	KTMediaPlayerController* videoController = [[[KTMediaPlayerController alloc] initWithContentURLs:vUrls
																							 andType:KTMediaPlayerControllerTypeVideo] autorelease];
	UITabBarItem* videoTabBarItem = [[[UITabBarItem alloc] initWithTitle:@"Video"
																   image:[UIImage imageNamed:@"Movie.png"]
																	 tag:4] autorelease];
	videoController.tabBarItem = videoTabBarItem;
	UINavigationController* videoNavigationController = [[[UINavigationController alloc] initWithRootViewController:videoController] autorelease];
	[viewControllers addObject:videoNavigationController];
	
	// create settings view controller
	KTSettings* settingsController = [[[KTSettings alloc] initWithStyle:UITableViewStyleGrouped] autorelease];
	UITabBarItem* settingsTabBarItem = [[[UITabBarItem alloc] initWithTitle:@"Settings"
																	  image:[UIImage imageNamed:@"Settings.png"]
																		tag:5] autorelease];
	settingsController.tabBarItem = settingsTabBarItem;
	UINavigationController* settingsNavController = [[[UINavigationController alloc] initWithRootViewController:settingsController] autorelease];
	[viewControllers addObject:settingsNavController];
	
	// insert view controllers to tab controller
	[tabBarController_ setViewControllers:viewControllers];
	
	// add tab bar view to window
	[self.window addSubview:tabBarController_.view];
}


- (void)applicationWillResignActive:(UIApplication *)application
{
    
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    
}


- (void)applicationWillEnterForeground:(UIApplication *)application
{
    
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    
}


- (void)applicationWillTerminate:(UIApplication *)application
{
    
}

#pragma mark -
#pragma mark UITabBarControllerDelegate

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
	if(!([viewController isKindOfClass:[KTMediaPlayerController class]] && [(KTMediaPlayerController*)viewController type] == KTMediaPlayerControllerTypeVideo))
		previouSelectedViewController_ = [tabBarController selectedIndex];
}

- (void)selectPreviousViewController
{
	[tabBarController_ setSelectedIndex:previouSelectedViewController_];
}

#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
	
}


- (void)dealloc
{
	[tabBarController_ release];
    [window release];
	
    [super dealloc];
}


@end
