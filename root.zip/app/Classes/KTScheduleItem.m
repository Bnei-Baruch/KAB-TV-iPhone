//
//  KTScheduleItem.m
//  ICSParser
//
//  Created by Leonid on 11.03.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "KTScheduleItem.h"


@implementation KTScheduleItem

@synthesize uid=uid_, status=status_, summary=summary_, description=description_, startDate=startDate_, endDate=endDate_, keyDate=keyDate_;

+ (KTScheduleItem*)itemWithICalComponent:(icalcomponent*)iCalComponent
{
	return [[[KTScheduleItem alloc] initWithICalComponent:iCalComponent] autorelease];
}

+ (NSDate*)dateFromICalDate:(NSString*)strDate
{
	if(!strDate || [strDate isEqualToString:@""] && [strDate length] != 15)
		return nil;
	
	/*NSRegularExpression* expression = [NSRegularExpression regularExpressionWithPattern:@"^[0-9]8T[0-9]6$"
																				options:NSRegularExpressionAnchorsMatchLines
																				  error:nil];*/
	
	NSString* dateStr2 = [NSString stringWithFormat:@"%@ %@ %@ %@ %@ %@",
						  [[strDate substringFromIndex:0] substringToIndex:4],
						  [[strDate substringFromIndex:4] substringToIndex:2],
						  [[strDate substringFromIndex:6] substringToIndex:2],
						  [[strDate substringFromIndex:9] substringToIndex:2],
						  [[strDate substringFromIndex:11] substringToIndex:2],
						  [[strDate substringFromIndex:13] substringToIndex:2]
						  ];
	
	NSDateFormatter* formatter = [[[NSDateFormatter alloc] init] autorelease];
	[formatter setDateFormat:@"yyyy MM dd HH mm ss"];
	
	NSDate* result = [formatter dateFromString:dateStr2];
	
	return result;
}

- (KTScheduleItem*)initWithICalComponent:(icalcomponent*)iCalComponent
{
	if(self = [self init])
	{
		icalproperty *p = icalcomponent_get_first_property(iCalComponent, ICAL_UID_PROPERTY);
		if(p)
		{
			icalvalue *v = icalproperty_get_value(p);
			uid_ = [[NSString stringWithCString:icalvalue_as_ical_string(v) encoding:NSUTF8StringEncoding] copy];
		}
		
		p = icalcomponent_get_first_property(iCalComponent, ICAL_STATUS_PROPERTY);
		if(p)
		{
			icalvalue *v = icalproperty_get_value(p);
			status_ = [[NSString stringWithCString:icalvalue_as_ical_string(v) encoding:NSUTF8StringEncoding] copy];
		}
		
		p = icalcomponent_get_first_property(iCalComponent, ICAL_SUMMARY_PROPERTY);
		if(p)
		{
			icalvalue *v = icalproperty_get_value(p);
			summary_ = [[NSString stringWithCString:icalvalue_as_ical_string(v) encoding:NSUTF8StringEncoding] stringByReplacingOccurrencesOfString:@"\\\\" withString:@"&slash"];
			summary_ = [summary_ stringByReplacingOccurrencesOfString:@"\\" withString:@""];
			summary_ = [[summary_ stringByReplacingOccurrencesOfString:@"&slash" withString:@"\\"] copy];
		}
		
		p = icalcomponent_get_first_property(iCalComponent, ICAL_DTSTART_PROPERTY);
		if(p)
		{
			icalvalue *v = icalproperty_get_value(p);
			
			//icalproperty_get_next_parameter
			icaltimetype icalTimeType = icaltime_from_string(icalvalue_as_ical_string(v));
			icaltimezone* icalTimeZone = icaltimezone_get_builtin_timezone_from_tzid([@"/citadel.org/20070227_1/Europe/Kiev"
																						cStringUsingEncoding:NSASCIIStringEncoding]);
			
			NSDateComponents* components = [[[NSDateComponents alloc] init] autorelease];
			[components setYear:icalTimeType.year];
			[components setMonth:icalTimeType.month];
			[components setDay:icalTimeType.day];
			[components setHour:icalTimeType.hour];
			[components setMinute:icalTimeType.minute];
			[components setSecond:icalTimeType.second];
			NSCalendar *cal = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];

			startDate_ = [cal dateFromComponents:components];
			int g = 0;
			int interval = [[NSTimeZone localTimeZone] secondsFromGMT] - icaltimezone_get_utc_offset(icalTimeZone, &icalTimeType, &g);
			startDate_ = [[startDate_ dateByAddingTimeInterval:interval] retain];
		}
		
		p = icalcomponent_get_first_property(iCalComponent, ICAL_DTEND_PROPERTY);
		if(p)
		{
			icalvalue *v = icalproperty_get_value(p);
			
			//icalproperty_get_next_parameter
			icaltimetype icalTimeType = icaltime_from_string(icalvalue_as_ical_string(v));
			icaltimezone* icalTimeZone = icaltimezone_get_builtin_timezone_from_tzid([@"/citadel.org/20070227_1/Europe/Kiev"
																					  cStringUsingEncoding:NSASCIIStringEncoding]);
			
			NSDateComponents* components = [[[NSDateComponents alloc] init] autorelease];
			[components setYear:icalTimeType.year];
			[components setMonth:icalTimeType.month];
			[components setDay:icalTimeType.day];
			[components setHour:icalTimeType.hour];
			[components setMinute:icalTimeType.minute];
			[components setSecond:icalTimeType.second];
			NSCalendar *cal = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
			
			endDate_ = [cal dateFromComponents:components];
			int g = 0;
			int interval = [[NSTimeZone localTimeZone] secondsFromGMT] - icaltimezone_get_utc_offset(icalTimeZone, &icalTimeType, &g);
			endDate_ = [[endDate_ dateByAddingTimeInterval:interval] retain];
			
			/*icalvalue *v = icalproperty_get_value(p);
			NSString* strDate = [NSString stringWithCString:icalvalue_as_ical_string(v) encoding:NSUTF8StringEncoding];
			int sevenHours = 7 * 60 * 60;
			endDate_ = [[[KTScheduleItem dateFromICalDate:strDate] dateByAddingTimeInterval:-sevenHours] retain];*/
		}
		
		p = icalcomponent_get_first_property(iCalComponent, ICAL_DESCRIPTION_PROPERTY);
		if(p)
		{
			icalvalue *v = icalproperty_get_value(p);
			description_ = [[NSString stringWithCString:icalvalue_as_ical_string(v) encoding:NSUTF8StringEncoding] stringByReplacingOccurrencesOfString:@"\\\\" withString:@"&slash"];
			description_ = [description_ stringByReplacingOccurrencesOfString:@"\\" withString:@""];
			description_ = [[description_ stringByReplacingOccurrencesOfString:@"&slash" withString:@"\\"] copy];
		}
		
		NSDateFormatter* formatter = [[[NSDateFormatter alloc] init] autorelease];
		[formatter setDateFormat:@"yyyyMMdd"];
		
		keyDate_ = [[formatter stringFromDate:startDate_] copy];
	}
	return self;
}

/*- (NSString*)description
{
	NSDateFormatter* formatter = [[[NSDateFormatter alloc] init] autorelease];
	[formatter setDateFormat:@"yyyy MM dd HH mm ss"];
	NSString* result = [NSString stringWithFormat:@"UID = %@\nStatus = %@\nSummary = %@\nStart = %@\nEnd = %@\nKeyDaty = %@",
						uid_, status_, summary_, [formatter stringFromDate:startDate_], [formatter stringFromDate:endDate_], keyDate_];
	return result;
}*/

- (void)dealloc
{
	[uid_ release]; uid_ = nil;
	[status_ release]; status_ = nil;
	[summary_ release]; summary_ = nil;
	[description_ release]; description_ = nil;
	[startDate_ release]; startDate_ = nil;
	[endDate_ release]; endDate_ = nil;
	[keyDate_ release]; keyDate_ = nil;
	
	[super dealloc];
}


@end
