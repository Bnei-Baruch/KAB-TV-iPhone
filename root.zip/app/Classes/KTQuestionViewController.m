    //
//  KTQuestionViewController.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "KTQuestionViewController.h"
#import "KTSettings.h"
#import "OrientationsController.h"
#import "SMSProgressBar.h"

#define TVMargin 0
#define AnimationDuration 0.4

@interface KTQuestionViewController (hidden) <UIAlertViewDelegate, UITextViewDelegate, UIWebViewDelegate, SMSProgressBarDelegate>

@end


@implementation KTQuestionViewController

#pragma mark -
#pragma mark View methods

- (void)loadView
{
	self.view = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 372)] autorelease];
	//[self.view setBackgroundColor:[UIColor colorWithRed:0.694f green:0.749f blue:0.914 alpha:1]];
	[self.view setBackgroundColor:[UIColor whiteColor]];
	
	// create text view
	textView_ = [[[UITextView alloc] initWithFrame:CGRectMake(TVMargin, TVMargin, self.view.frame.size.width - TVMargin * 2, self.view.frame.size.height)] autorelease];
	[textView_ setEditable:YES];
	[textView_ setDelegate:self];
	[textView_ setFont:[UIFont fontWithName:@"Helvetica" size:16.0f]];
	[self.view addSubview:textView_];
	
	// create nav bar
	navBar_ = [[[UINavigationBar alloc] initWithFrame:CGRectMake(0, textView_.frame.size.height, 320.0f, 44.0f)] autorelease];
	[navBar_ setAlpha:0];
	UINavigationItem* navItem = [[[UINavigationItem alloc] initWithTitle:@""] autorelease];
	navItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Send"
																   style:UIBarButtonItemStyleBordered
																  target:self
																  action:@selector(sendToucted:)] autorelease];
	navItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Clear"
																  style:UIBarButtonItemStyleBordered
																 target:self
																 action:@selector(clearTouched:)] autorelease];
	[navBar_ pushNavigationItem:navItem animated:NO];
	
	/*UINavigationBar* bar_2 = [[[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)] autorelease];
	UINavigationItem* item_2 = [[[UINavigationItem alloc] initWithTitle:@""] autorelease];
	item_2.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Clear"
																  style:UIBarButtonItemStyleBordered
																 target:self
																 action:@selector(clearTouched:)] autorelease];
	[bar_2 pushNavigationItem:item_2 animated:NO];
	[navItem setTitleView:bar_2];*/
	[self.view addSubview:navBar_];
	
	// create activity indicator
	flower_ = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite] autorelease];
	[flower_ setCenter:CGPointMake(self.view.frame.size.width / 2, self.view.frame.size.height / 2)];
	[flower_ setHidesWhenStopped:YES];
	[flower_ stopAnimating];
	[self.view addSubview:flower_];
	
	// create webview
	webView_ = [[UIWebView alloc] init];
	
	SMSProgressBar* progresssBar = [[[SMSProgressBar alloc] initWithFrame:CGRectMake(0, 0, 200, 44)] autorelease];
	[progresssBar setHidden:YES];
	[progresssBar setDelegate:self];
	[self.navigationItem setTitleView:progresssBar];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
	[[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO];
	[[OrientationsController sharedController] setSupportedOrientations:SO_UIInterfaceOrientationPortrait];
	
	[textView_ becomeFirstResponder];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	return [[OrientationsController sharedController] shouldAutorotateToOrientation:interfaceOrientation];
}

#pragma mark -
#pragma mark Methods

- (void)sendToucted:(UIButton*)sender
{
	NSString* userName = [[NSUserDefaults standardUserDefaults] objectForKey:udNameKey];
	NSString* userFrom = [[NSUserDefaults standardUserDefaults] objectForKey:udFromKey];
	NSString* text = [textView_.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
	
	if(!text || [text isEqualToString:@""])
	{
		UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Warning"
														 message:@"Please enter message text!"
														delegate:nil
											   cancelButtonTitle:@"OK"
											   otherButtonTitles:nil] autorelease];
		[alert show];
		
		return;
	}
	if(!userName || [userName isEqualToString:@""] || !userFrom || [userFrom isEqualToString:@""])
	{
		UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Warning"
														 message:@"Please enter your name and here are you from in settings!"
														delegate:nil
											   cancelButtonTitle:@"OK"
											   otherButtonTitles:nil] autorelease];
		[alert show];
		
		return;
	}
	[navBar_ setUserInteractionEnabled:FALSE];
	//[self.view setUserInteractionEnabled:FALSE];
	
	[webView_ setDelegate:self];
	[webView_ loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://kab.tv/rus/ask.php?lang=English"]]];
	//[webView_ loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.google.com.ua"]]];
	
	/*sendingView_ = [[[UIView alloc] initWithFrame:CGRectMake(100, (self.view.frame.size.width - 44) / 2.0f, 120, 44)] autorelease];
	[sendingView_ setAlpha:0];
	[sendingView_.layer setCornerRadius:10];
	[sendingView_ setBackgroundColor:[UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:0.9]];
	[self.view addSubview:sendingView_];
	
	UILabel* label = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 80, 44)] autorelease];
	[label setTextColor:[UIColor whiteColor]];
	[label setBackgroundColor:[UIColor clearColor]];
	[label setTextAlignment:UITextAlignmentCenter];
	[label setText:@"Sending..."];
	[label setFont:[UIFont boldSystemFontOfSize:15.0f]];
	[sendingView_ addSubview:label];
	
	[sendingView_ addSubview:flower_];
	[flower_ setCenter:CGPointMake(100, 22)];
	[flower_ startAnimating];
	
	[UIView beginAnimations:@"show" context:nil];
	[UIView setAnimationDuration:0.4];
	
	[sendingView_ setAlpha:1];
	
	[UIView commitAnimations];*/
	
	[(SMSProgressBar*)self.navigationItem.titleView setHidden:FALSE];
	[(SMSProgressBar*)self.navigationItem.titleView start];
}

- (void)clearTouched:(UIButton*)sender
{
	UIAlertView* confirmationAlert = [[[UIAlertView alloc] initWithTitle:@"Warning"
																 message:@"Do you want to clear message?"
																delegate:self
													   cancelButtonTitle:@"Cancel"
													   otherButtonTitles:@"OK", nil] autorelease];
	[confirmationAlert show];
}

- (void)doneTouched:(id)sender
{
	self.navigationItem.rightBarButtonItem = nil;
	
	[textView_ resignFirstResponder];
	
	[UIView beginAnimations:@"ShowBar" context:nil];
	[UIView setAnimationDuration:AnimationDuration];
	
	[navBar_ setAlpha:0];
	[textView_ setFrame:CGRectMake(TVMargin, TVMargin, self.view.frame.size.width - TVMargin * 2, self.view.frame.size.height)];
	[navBar_ setFrame:CGRectMake(navBar_.frame.origin.x, self.view.frame.size.height, navBar_.frame.size.width, navBar_.frame.size.height)];
	
	[UIView commitAnimations];
}

- (void)failResult
{
	//[flower_ stopAnimating];
	[UIView beginAnimations:@"hide" context:nil];
	[UIView setAnimationDuration:0.4];
	[UIView setAnimationBeginsFromCurrentState:YES];
	
	[sendingView_ setAlpha:0];
	
	[UIView commitAnimations];
	
	[self.view setUserInteractionEnabled:YES];
	
	UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
													 message:@"Question not sended"
													delegate:nil
										   cancelButtonTitle:@"OK"
										   otherButtonTitles:nil] autorelease];
	[alert show];
	[navBar_ setUserInteractionEnabled:YES];
	
	[self.navigationItem.titleView setHidden:YES];
}

- (void)successResult
{
	//[flower_ stopAnimating];
	[UIView beginAnimations:@"hide" context:nil];
	[UIView setAnimationDuration:0.4];
	[UIView setAnimationBeginsFromCurrentState:YES];
	
	[sendingView_ setAlpha:0];
	
	[UIView commitAnimations];
	
	[self.view setUserInteractionEnabled:YES];
	
	NSString* userName = [[NSUserDefaults standardUserDefaults] objectForKey:udNameKey];
	NSString* userFrom = [[NSUserDefaults standardUserDefaults] objectForKey:udFromKey];
	NSString* text = [textView_.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
	
	NSString* js = [NSString stringWithFormat:@"%@%@%@%@",
					[NSString stringWithFormat:@"document.getElementById('QName').value = \"%@\";", userName],
					[NSString stringWithFormat:@"document.getElementById('QFrom').value = \"%@\";", userFrom],
					[NSString stringWithFormat:@"document.getElementById('QQuestion').value = \"%@\";", text],
					@"document.qForm.submit();"];
	[webView_ stringByEvaluatingJavaScriptFromString:js];
	
	UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Done"
													 message:@"Question sended successful"
													delegate:nil
										   cancelButtonTitle:@"OK"
										   otherButtonTitles:nil] autorelease];
	[alert show];
	[webView_ setDelegate:nil];
	
	[textView_ setText:@""];
	[navBar_ setUserInteractionEnabled:YES];
	
	[self.navigationItem.titleView setHidden:YES];
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
	textView_ = nil;
	flower_ = nil;
	navBar_ = nil;
	
    [super viewDidUnload];
}


- (void)dealloc
{
	[webView_ release];
	
    [super dealloc];
}

#pragma mark -
#pragma mark UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
																							target:self
																							action:@selector(doneTouched:)] autorelease];
	
	[UIView beginAnimations:@"ShowBar" context:nil];
	[UIView setAnimationDuration:AnimationDuration];
	
	[navBar_ setAlpha:1];
	[textView_ setFrame:CGRectMake(TVMargin, TVMargin, self.view.frame.size.width - TVMargin * 2, 156.0f)];
	[navBar_ setFrame:CGRectMake(navBar_.frame.origin.x, 156.0f, navBar_.frame.size.width, navBar_.frame.size.height)];
	
	[UIView commitAnimations];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
	[textView resignFirstResponder];
	
	[UIView beginAnimations:@"ShowBar" context:nil];
	[UIView setAnimationDuration:AnimationDuration];
	
	[navBar_ setAlpha:0];
	[textView_ setFrame:CGRectMake(TVMargin, TVMargin, self.view.frame.size.width - TVMargin * 2, self.view.frame.size.height)];
	[navBar_ setFrame:CGRectMake(navBar_.frame.origin.x, self.view.frame.size.height, navBar_.frame.size.width, navBar_.frame.size.height)];
	
	[UIView commitAnimations];
}

#pragma mark -
#pragma mark UIWebViewDelegate

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	[(SMSProgressBar*)self.navigationItem.titleView stop];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	[(SMSProgressBar*)self.navigationItem.titleView cancel];
}

#pragma mark -
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if(buttonIndex == 1)
		[textView_ setText:@""];
}

#pragma mark -
#pragma mark 

- (void)progressFinished:(id)sender resultSelf:(BOOL)selfFinished
{
	[sender setHidden:YES];
	
	[webView_ stopLoading];
	
	if(selfFinished)
		[self failResult];
	else
		[self successResult];
}

@end
