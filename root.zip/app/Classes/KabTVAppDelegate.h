//
//  KabTVAppDelegate.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KTFirstFakeViewController.h"

@interface KabTVAppDelegate : NSObject <UIApplicationDelegate>
{
    UIWindow *window;
	
	UITabBarController* tabBarController_;
	KTFirstFakeViewController* firstViewController_;
	
	int previouSelectedViewController_;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

- (void)selectPreviousViewController;

@end

