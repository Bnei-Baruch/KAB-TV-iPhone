/*
 *  OrientationsController.h
 *  Livestream
 *
 *  Copyright 2010 Gennadii Ivanov. All rights reserved.
 *
 */

#import <UIKit/UIKit.h>


typedef enum
{
	SO_UIInterfaceOrientationPortrait = 1<<0,
	SO_UIInterfaceOrientationPortraitUpsideDown = 1<<1,
	SO_UIInterfaceOrientationLandscapeLeft = 1<<2,
	SO_UIInterfaceOrientationLandscapeRight = 1<<3
} SupprotedOrientations;

@interface OrientationsController : NSObject
{
	NSUInteger supportedOrientations_;
}

- (void)setSupportedOrientations:(NSInteger)orientations;
- (BOOL)shouldAutorotateToOrientation:(UIInterfaceOrientation)orientation;

+ (OrientationsController*)sharedController;

+ (NSInteger)allOrientations;
+ (NSInteger)allOrientationsExceptPortraitUpsideDown;
+ (NSInteger)verticalOrientation;
+ (NSInteger)horizontalOrientation;

@end
