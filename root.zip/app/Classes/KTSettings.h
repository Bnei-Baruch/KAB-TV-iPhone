//
//  KTSettings.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

#define udNameKey @"KavTVName"
#define udFromKey @"KavTVFrom"


@interface KTSettings : UITableViewController
<UITextFieldDelegate,
UIAlertViewDelegate,
CLLocationManagerDelegate>
{
	NSString* name_;
	NSString* from_;
	
	UITextField* fromTF_;
	UITextField* nameTF_;
	
	BOOL firstAppear_;
	
	UIActivityIndicatorView* flower_;
	CLLocationManager* locationManager_;
	
	NSTimer* timer_;
	
	NSMutableData* responceData_;
}

@end
