    //
//  KTCalendar.m
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import "KTCalendar.h"
#import "KTScheduleItem.h"
#import "NSString+HTML.h"
#import "KTEventDesctiptionViewController.h"
#import "OrientationsController.h"
#import "GTMNSString+HTML.h"

#define HeaderHeight 44.0f
#define HeaderButtonsWidth 35.0f
#define CellDatesViewWidth 70.0f

@interface KTCalendar (hidden) <UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate>

- (void)switchToIndex:(int)index;
- (void)reinit;
- (void)loadData;
- (NSString*)clearTextWithHTML:(NSString*)htmlText;

@end


@implementation KTCalendar

#pragma mark -
#pragma mark View lifecicle

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	[self.view setBackgroundColor:[UIColor groupTableViewBackgroundColor]];
	
	[self.navigationItem setTitle:@"Schedule"];
	
	// creat hearder view
	headerContainer_ = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, HeaderHeight)] autorelease];
	[headerContainer_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
	[headerContainer_ setBackgroundColor:[UIColor greenColor]];
	[headerContainer_ setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:headerContainer_];
	
	UIImageView* headerBackgroung = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"HeaderBackround.png"]] autorelease];
	[headerBackgroung setFrame:CGRectMake(0, 0, headerContainer_.frame.size.width, headerContainer_.frame.size.height)];
	[headerBackgroung setAutoresizingMask:UIViewAutoresizingFlexibleWidth | 
	 UIViewAutoresizingFlexibleHeight];
	[headerContainer_ addSubview:headerBackgroung];
	
	// add left button
	UIButton* leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[leftButton addTarget:self
				   action:@selector(leftTouched:)
		 forControlEvents:UIControlEventTouchUpInside];
	[leftButton setFrame:CGRectMake(0, 0, HeaderButtonsWidth, headerContainer_.frame.size.height)];
	[leftButton setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
	[headerContainer_ addSubview:leftButton];
	
	// add image to button
	UIImageView* imView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ArrowLeft.png"]] autorelease];
	[leftButton addSubview:imView];
	
	// add right button
	UIButton* rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[rightButton addTarget:self
				   action:@selector(rightTouched:)
		 forControlEvents:UIControlEventTouchUpInside];
	[rightButton setFrame:CGRectMake(headerContainer_.frame.size.width - HeaderButtonsWidth, 0, HeaderButtonsWidth, headerContainer_.frame.size.height)];
	[rightButton setAutoresizingMask:UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight];
	[headerContainer_ addSubview:rightButton];
	
	// add image to button
	imView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ArrowRight.png"]] autorelease];
	[rightButton addSubview:imView];
	
	// add scroll view to header
	headerScrollView_ = [[[UIScrollView alloc] initWithFrame:CGRectMake(HeaderButtonsWidth,
																		0,
																		headerContainer_.frame.size.width - HeaderButtonsWidth * 2,
																		headerContainer_.frame.size.height)] autorelease];
	[headerScrollView_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
	 UIViewAutoresizingFlexibleHeight];
	[headerScrollView_ setDelegate:self];
	[headerScrollView_ setBackgroundColor:[UIColor clearColor]];
	[headerScrollView_ setPagingEnabled:YES];
	[headerContainer_ addSubview:headerScrollView_];
	
	eventsTable_ = [[[UITableView alloc] initWithFrame:CGRectMake(0, HeaderHeight, self.view.frame.size.width, self.view.frame.size.height - HeaderHeight)
												 style:UITableViewStylePlain] autorelease];
	eventsTable_.delegate = eventsTable_.dataSource = self;
	[eventsTable_ setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
	[eventsTable_ setSeparatorStyle:UITableViewCellSeparatorStyleNone];
	[eventsTable_ setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:eventsTable_];
	
	flower_ = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray] autorelease];
	[flower_ setAutoresizingMask:UIViewAutoresizingFlexibleTopMargin |
	 UIViewAutoresizingFlexibleRightMargin |
	 UIViewAutoresizingFlexibleBottomMargin |
	 UIViewAutoresizingFlexibleLeftMargin];
	[flower_ setHidesWhenStopped:YES];
	[flower_ stopAnimating];
	[flower_ setCenter:CGPointMake(self.view.frame.size.width / 2.0f, self.view.frame.size.height / 2.0f)];
	[self.view addSubview:flower_];
	
	// create fake empty data
	[events_ release];
	events_ = [[NSMutableDictionary alloc] init];
	[sortedKeys_ release];
	sortedKeys_ = [[NSMutableArray alloc] init];
	
	self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Today"
																			  style:UIBarButtonItemStyleBordered
																			 target:self
																			 action:@selector(setToday:)] autorelease];
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh
																							target:self
																							action:@selector(loadData)] autorelease];
	
	[self reinit];
	
	[self loadData];
}

- (void)setToday:(id)sender
{
	NSDateFormatter* formater = [[[NSDateFormatter alloc] init] autorelease];
	[formater setDateFormat:@"yyyyMMdd"];
	NSString* todayKey = [formater stringFromDate:[NSDate date]];
	int index = -1;
	for(int i = 0; i < [sortedKeys_ count]; i++)
		if([[sortedKeys_ objectAtIndex:i] isEqualToString:todayKey])
			index = i;
	
	if(index >= 0)
		[self switchToIndex:index];
	else
	{
		[[[[UIAlertView alloc] initWithTitle:@"Warning"
									 message:@"The schedule for today has been found, please resresh schedule"
									delegate:nil
						   cancelButtonTitle:@"OK"
						   otherButtonTitles:nil] autorelease] show];
	}
}

- (void)viewWillAppear:(BOOL)animated
{
	[[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO];
	[[OrientationsController sharedController] setSupportedOrientations:SO_UIInterfaceOrientationPortrait];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	NSLog(@"%@::%@", [[self class] description], NSStringFromSelector(_cmd));
	
	return [[OrientationsController sharedController] shouldAutorotateToOrientation:interfaceOrientation];
}

#pragma mark -
#pragma mark Methods

- (void)leftTouched:(id)sender
{
	[self switchToIndex:selectedIndex_ - 1];
}

- (void)rightTouched:(id)sender
{
	[self switchToIndex:selectedIndex_ + 1];
}

- (void)reinit
{
	// remove all subviews
	while ([[headerScrollView_ subviews] count])
		[[[headerScrollView_ subviews] objectAtIndex:0] removeFromSuperview];
	
	// setContentSize
	[headerScrollView_ setContentSize:CGSizeMake(headerScrollView_.frame.size.width * [sortedKeys_ count],
												 headerScrollView_.frame.size.height)];
	
	previousSelectedIndex_ = -1;
	selectedIndex_ = -1;
	
	// create labels
	for (int i = 0; i < [sortedKeys_ count]; i++)
	{
		UILabel* label = [[[UILabel alloc] initWithFrame:CGRectMake(i * headerScrollView_.frame.size.width,
																	0,
																	headerScrollView_.frame.size.width,
																	headerScrollView_.frame.size.height)] autorelease];
		[label setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
		 UIViewAutoresizingFlexibleHeight |
		 UIViewAutoresizingFlexibleTopMargin |
		 UIViewAutoresizingFlexibleBottomMargin |
		 UIViewAutoresizingFlexibleLeftMargin |
		 UIViewAutoresizingFlexibleRightMargin];
		[label setBackgroundColor:[UIColor clearColor]];
		[label setFont:[UIFont systemFontOfSize:20]];
		[label setShadowColor:[UIColor blackColor]];
		[label setShadowOffset:CGSizeMake(0, 1)];
		[label setTextColor:[UIColor whiteColor]];
		[label setTextAlignment:UITextAlignmentCenter];
		
		NSDate* date = [(KTScheduleItem*)[(NSArray*)[events_ objectForKey:[sortedKeys_ objectAtIndex:i]] objectAtIndex:0] startDate];
		NSDateFormatter* formatter = [[[NSDateFormatter alloc] init] autorelease];
		[formatter setDateFormat:@"MMMM d"];
		[label setText:[formatter stringFromDate:date]];
		
		[headerScrollView_ addSubview:label];
	}
	
	[self switchToIndex:0];
}

- (void)switchToIndex:(int)index
{
	if([sortedKeys_ count] == 0)
		selectedIndex_ = -1;
	
	/*if(index < 0 || index >= [sortedKeys_ count])
		return;*/
	
	if(index < 0)
		index = [sortedKeys_ count] - 1;
	else if(index >= [sortedKeys_ count])
		index = 0;
	
	previousSelectedIndex_ = selectedIndex_;
	selectedIndex_ = index;
	
	[headerScrollView_ scrollRectToVisible:CGRectMake(index * headerScrollView_.frame.size.width,
													  0,
													  headerScrollView_.frame.size.width,
													  headerScrollView_.frame.size.height)
								  animated:YES];
	
	//[eventsTable_ reloadData];
	
	[UIView beginAnimations:@"FadeInAnimation" context:nil];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDuration:0.3];
	[UIView setAnimationWillStartSelector:@selector(animationWillStart:)];
	[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
	
	[eventsTable_ setAlpha:0];
	
	[UIView commitAnimations];
}

#pragma mark -
#pragma mark Animations

- (void)animationWillStart:(id)sender
{
	
}

- (void)animationDidStop:(id)sender
{
	if([sender isEqualToString:@"FadeInAnimation"])
	{
		[eventsTable_ reloadData];
		
		[UIView beginAnimations:@"FadeOutAnimation" context:nil];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:0.3];
		[UIView setAnimationWillStartSelector:@selector(animationWillStart:)];
		[UIView setAnimationDidStopSelector:@selector(animationDidStop:)];
		
		[eventsTable_ setAlpha:1];
		
		[UIView commitAnimations];
	}
}

#pragma mark -
#pragma mark Loading

- (void)loadData
{
	[self.view setUserInteractionEnabled:FALSE];
	[flower_ startAnimating];
	[self performSelectorInBackground:@selector(loadDataInBackground) withObject:nil];
}

- (void)loadDataInBackground
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://kaushan.com/kab/schedule/kab_tv.ical"]];
	NSError* error = nil;
	NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
	if(error)	
	{
		[self performSelectorOnMainThread:@selector(loadingDataFailedOnMain) withObject:nil waitUntilDone:YES];
		return;
	}
	NSString* dataString = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
	
	NSMutableArray* scheduleItems = [NSMutableArray array];
	
	icalcomponent *root = icalparser_parse_string([dataString cStringUsingEncoding:NSUTF8StringEncoding]);
	if (root)
	{
		icalcomponent *component = icalcomponent_get_first_component(root, ICAL_VEVENT_COMPONENT);
		while (component)
		{
			KTScheduleItem* schItem = [KTScheduleItem itemWithICalComponent:component];
			[scheduleItems addObject:schItem];
			
			component = icalcomponent_get_next_component(root, ICAL_ANY_COMPONENT);
		}
		icalcomponent_free(root);
	}
		
	
	[self performSelectorOnMainThread:@selector(dataLoadFinishOnMain:)
						   withObject:scheduleItems
						waitUntilDone:YES];
	
	[pool release];
}

- (void)loadingDataFailedOnMain
{
	[[[[UIAlertView alloc] initWithTitle:@"Error"
								 message:@"Please check your internet connection and try anain"
								delegate:nil
					   cancelButtonTitle:@"OK"
					   otherButtonTitles:nil] autorelease] show];
	
	[flower_ stopAnimating];
	[self.view setUserInteractionEnabled:YES];
}

- (void)dataLoadFinishOnMain:(NSArray*)scheduleItems
{
	[flower_ stopAnimating];
	[self.view setUserInteractionEnabled:YES];
	
	// create new dictionary
	[events_ release];
	events_ = [[NSMutableDictionary alloc] init];
	
	for (KTScheduleItem* item in scheduleItems)
	{
		// get items of day
		NSMutableArray* itemsOfDay = [events_ objectForKey:[item keyDate]];
		if(!itemsOfDay)
		{
			itemsOfDay = [NSMutableArray array];
			[events_ setObject:itemsOfDay forKey:[item keyDate]];
		}
		
		// add item
		[itemsOfDay addObject:item];
	}
	
	// make keys array for sort
	[sortedKeys_ release];
	sortedKeys_ = [[NSMutableArray alloc] initWithArray:[events_ allKeys]];
	
	// sorting
	int i = 0;
	while(i < [sortedKeys_ count] - 1)
	{
		int value_1 = [[sortedKeys_ objectAtIndex:i] intValue];
		int value_2 = [[sortedKeys_ objectAtIndex:i+1] intValue];
		
		if(value_1 > value_2)
		{
			NSString* tmpKey = [[sortedKeys_ objectAtIndex:i] retain];
			[sortedKeys_ removeObjectAtIndex:i];
			[sortedKeys_ insertObject:tmpKey atIndex:i+1];
			[tmpKey release];
			
			i--;
			if(i < 0)
				i = 0;
		}
		else
			i++;
	}
	
	// create all variable
	[self reinit];
}

#pragma mark -
#pragma mark UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if(selectedIndex_ < 0 || ![sortedKeys_ count])
		return 0;
	
	return [[events_ objectForKey:[sortedKeys_ objectAtIndex:selectedIndex_]] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSString *cellIdentfifier = @"cellIdentfifier";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentfifier];
    
	if (cell == nil)
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentfifier] autorelease];
	
	// remove all subviews
	while ([[cell.contentView subviews] count])
		[[[cell.contentView subviews] objectAtIndex:0] removeFromSuperview];
	
	// get item
	KTScheduleItem* schItem = [(NSArray*)[events_ objectForKey:[sortedKeys_ objectAtIndex:selectedIndex_]] objectAtIndex:indexPath.row];
	
	// add backgrount image
	UIImageView* background = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"CellBackground.png"]] autorelease];
	[background setFrame:CGRectMake(0, 0, cell.contentView.frame.size.width, cell.contentView.frame.size.height)];
	[background setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
	 UIViewAutoresizingFlexibleHeight];
	[cell.contentView addSubview:background];
	
	// add view for dates
	UIView* datesView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, CellDatesViewWidth, cell.contentView.frame.size.height)] autorelease];
	[datesView setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
	[cell.contentView addSubview:datesView];
	[datesView setBackgroundColor:[UIColor clearColor]];
	
	NSDateFormatter* formatter = [[[NSDateFormatter alloc] init] autorelease];
	[formatter setDateFormat:@"H:mm"];
	
	// add label start date
	UILabel* label = [[[UILabel alloc] initWithFrame:CGRectMake(5, 0, datesView.frame.size.width - 10, datesView.frame.size.height)] autorelease];
	[label setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
	 UIViewAutoresizingFlexibleHeight |
	 UIViewAutoresizingFlexibleBottomMargin];
	[label setText:[formatter stringFromDate:[schItem startDate]]];
	[label setTextAlignment:UITextAlignmentCenter];
	[label setFont:[UIFont boldSystemFontOfSize:20.0f]];
	[label setBackgroundColor:[UIColor clearColor]];
	[label setTextColor:[UIColor darkGrayColor]];
	[label setShadowColor:[UIColor whiteColor]];
	[label setShadowOffset:CGSizeMake(0, -1)];
	[datesView addSubview:label];
	
	// add label for summary
	UILabel* labelSummary = [[[UILabel alloc] initWithFrame:CGRectMake(CellDatesViewWidth,
																	   0,
																	   cell.frame.size.width - CellDatesViewWidth,
																	   cell.frame.size.height)] autorelease];
	[labelSummary setAutoresizingMask:UIViewAutoresizingFlexibleWidth |
	 UIViewAutoresizingFlexibleHeight];
	[labelSummary setText:[[[schItem summary] stringByConvertingHTMLToPlainText] gtm_stringByUnescapingFromHTML]];
	[labelSummary setNumberOfLines:1];
	[labelSummary setLineBreakMode:UILineBreakModeTailTruncation];
	[labelSummary setFont:[UIFont boldSystemFontOfSize:20.0f]];
	[labelSummary setBackgroundColor:[UIColor clearColor]];
	[labelSummary setTextColor:[UIColor blackColor]];
	[labelSummary setShadowColor:[UIColor whiteColor]];
	[labelSummary setShadowOffset:CGSizeMake(0, -1)];
	[cell.contentView addSubview:labelSummary];
	
	[cell setSelectionStyle:UITableViewCellSelectionStyleNone];
	
	return cell;
}

#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 91.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	// get item
	KTScheduleItem* schItem = [(NSArray*)[events_ objectForKey:[sortedKeys_ objectAtIndex:selectedIndex_]] objectAtIndex:indexPath.row];
	KTEventDesctiptionViewController* eventController = [[[KTEventDesctiptionViewController alloc] initWithScheduleItem:schItem] autorelease];
	[self.navigationController pushViewController:eventController animated:YES];
}

#pragma mark UIScrollViewDelegate

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	if(scrollView == headerScrollView_)
	{
		if(!decelerate)
		{
			// get center absciss scrolled
			int scrolledX = scrollView.contentOffset.x + scrollView.frame.size.width / 2;
			
			// get scrolled index
			int index = scrolledX / scrollView.frame.size.width;
			
			// switch to index if needed
			if(selectedIndex_ != index && index >= 0 && index < [sortedKeys_ count])
				[self switchToIndex:index];
		}
	}
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
	if(scrollView == headerScrollView_)
	{
		// get center absciss scrolled
		int scrolledX = scrollView.contentOffset.x + scrollView.frame.size.width / 2;
		
		// get scrolled index
		int index = scrolledX / scrollView.frame.size.width;
		
		// switch to index if needed
		if(selectedIndex_ != index && index >= 0 && index < [sortedKeys_ count])
			[self switchToIndex:index];
	}
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
	headerContainer_ = nil;
	eventsTable_ = nil;
	flower_ = nil;
	headerScrollView_ = nil;
	
    [super viewDidUnload];
}


- (void)dealloc
{
	[events_ release]; events_ = nil;
	[sortedKeys_ release]; sortedKeys_ = nil;
	
    [super dealloc];
}


@end
