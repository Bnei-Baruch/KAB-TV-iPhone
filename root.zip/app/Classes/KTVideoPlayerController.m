    //
//  KTVideoPlayerController.m
//  KabTV
//
//  Copyright 2011 Leonik Reutov. All rights reserved.
//

#import "KTVideoPlayerController.h"
#import "OrientationsController.h"

#define FadeVisibleDuration 3
#define FadeHiddingInterval 0.01
#define FadeHiddingDuration 1
#define kNavBarTag 1000


@implementation KTVideoPlayerController

@synthesize url=url_, delegate=delegate_;

- (id)initWithContentURL:(NSURL*)url delegate:(id<KTVideoPlayerControllerDelegate>)delegate
{
	if(self = [super init])
	{
		url_ = [url retain];
		delegate_ = delegate;
		
		[self setHidesBottomBarWhenPushed:YES];
		
		mediaPlayer_ = [[MPMoviePlayerController alloc] initWithContentURL:url_];
		[mediaPlayer_ setMovieControlMode:MPMovieControlModeHidden];
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:mediaPlayer_];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackStateDidChange:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:mediaPlayer_];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadStateDidChange:) name:MPMoviePlayerLoadStateDidChangeNotification object:mediaPlayer_];
	}
	return self;
}

- (id)initWithMediaPlayer:(MPMoviePlayerController*) mediaPlayer delegate:(id<KTVideoPlayerControllerDelegate>)delegate
{
	if(self = [super init])
	{
		mediaPlayer_ = [mediaPlayer retain];
		[mediaPlayer_ setMovieControlMode:MPMovieControlModeHidden];
		delegate_ = delegate;
		
		[self setHidesBottomBarWhenPushed:YES];
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:mediaPlayer_];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackStateDidChange:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:mediaPlayer_];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadStateDidChange:) name:MPMoviePlayerLoadStateDidChangeNotification object:mediaPlayer_];
	}
	return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	[self.view setBackgroundColor:[UIColor blackColor]];
}

- (void)viewWillAppear:(BOOL)aminated
{
	[[UIApplication sharedApplication] setStatusBarHidden:YES animated:NO];
	[self.navigationController setNavigationBarHidden:YES animated:NO];
	
	[self.view setFrame:CGRectMake(0, 0, 320, 480)];
	
	mediaPlayer_.scalingMode = MPMovieScalingModeAspectFill;
	mediaPlayer_.view.transform = CGAffineTransformMakeRotation(M_PI/2);
	[mediaPlayer_.view setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
	[self.view addSubview:mediaPlayer_.view];
	
	UIButton* playerButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[playerButton setFrame:CGRectMake(0, 0, 480, 320)];
	[playerButton setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
	[playerButton addTarget:self
					 action:@selector(playerButtonHandler:)
		   forControlEvents:UIControlEventTouchUpInside];
	[mediaPlayer_.view addSubview:playerButton];
	
	UINavigationBar* bar = [[[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, 480, 44.0f)] autorelease];
	[bar setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
	[bar setBarStyle:UIBarStyleBlack];
	[bar setTag:kNavBarTag];
	[mediaPlayer_.view addSubview:bar];
	
	UINavigationItem* navItem = [[[UINavigationItem alloc] initWithTitle:@""] autorelease];
	navItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
																			   target:self
																			   action:@selector(doneTouch:)] autorelease];
	[bar pushNavigationItem:navItem animated:NO];
	
	fadeType_ = FadeTypeVisible;
	[fadeTimer_ invalidate];
	[fadeTimer_ release];
	fadeTimer_ = [[NSTimer scheduledTimerWithTimeInterval:FadeVisibleDuration
												   target:self
												 selector:@selector(timerHandler:)
												 userInfo:nil
												  repeats:NO] retain];
	
	[mediaPlayer_ play];
	
	[[OrientationsController sharedController] setSupportedOrientations:SO_UIInterfaceOrientationPortrait];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return [[OrientationsController sharedController] shouldAutorotateToOrientation:interfaceOrientation];
}

- (void)doneTouch:(id)sender
{
	[mediaPlayer_ stop];
	[delegate_ videoPlayerWillPop:self];
	
	[self.navigationController popViewControllerAnimated:NO];
}

#pragma mark -
#pragma mark Media player

- (void)playbackDidFinish:(NSNotification*)notification
{
	if([notification object] == mediaPlayer_)
	{
		NSLog(@"KTVideoPlayerController::playbackDidFinish %d", mediaPlayer_.movieMediaTypes);
		NSString *reasonDescription = @"Uknown";
		NSNumber *reason = [[notification userInfo] objectForKey:@"MPMoviePlayerPlaybackDidFinishReasonUserInfoKey"];
		if (reason)
		{
			switch ([reason intValue])
			{
				case MPMovieFinishReasonPlaybackEnded:
					reasonDescription = @"MPMovieFinishReasonPlaybackEnded";
					[self performSelector:@selector(doneTouch:) withObject:nil afterDelay:0];
					break;
				case MPMovieFinishReasonPlaybackError:
					reasonDescription = @"MPMovieFinishReasonPlaybackError";
					
					NSLog(@"Show error");
					UIAlertView* alert = [[[UIAlertView alloc] initWithTitle:@"Error"
																	 message:@"Cant connect to video."
																	delegate:nil
														   cancelButtonTitle:@"OK"
														   otherButtonTitles:nil] autorelease];
					[alert show];
					[self performSelector:@selector(doneTouch:) withObject:nil afterDelay:0];
					break;
				case MPMovieFinishReasonUserExited:
					reasonDescription = @"MPMovieFinishReasonUserExited";
					break;
				default:
					break;
			}
		}
		
		NSLog(@"KTVideoPlayerController::playbackDidFinish reason = %@", reasonDescription);
	}
}

- (void)loadStateDidChange:(NSNotification*)notification
{
	if([notification object] == mediaPlayer_)
	{
		NSLog(@"KTVideoPlayerController::loadStateDidChange %d", mediaPlayer_.loadState);
	}
}

- (void)playbackStateDidChange:(NSNotification*)notification
{
	if([notification object] == mediaPlayer_)
	{
		NSLog(@"KTVideoPlayerController::playbackStateDidChange %d", mediaPlayer_.playbackState);
	}
}

#pragma mark Fade

- (void)playerButtonHandler:(id)sender
{
	if(fadeType_ == FadeTypeVisible)
	{
		fadeType_ = FadeTypeNone;
		[[mediaPlayer_.view viewWithTag:kNavBarTag] setAlpha:0];
		[fadeTimer_ invalidate];
		[fadeTimer_ release];
		fadeTimer_ = nil;
	}
	else
	{
		fadeType_ = FadeTypeVisible;
		[[mediaPlayer_.view viewWithTag:kNavBarTag] setAlpha:1];
		[fadeTimer_ invalidate];
		[fadeTimer_ release];
		fadeTimer_ = [[NSTimer scheduledTimerWithTimeInterval:FadeVisibleDuration
													   target:self
													 selector:@selector(timerHandler:)
													 userInfo:nil
													  repeats:NO] retain];
	}
}

- (void)timerHandler:(NSNotification*)notify
{
	switch (fadeType_)
	{
		case FadeTypeNone:
			break;
		case FadeTypeVisible:
			fadeType_ = FadeTypeHidding;
			[fadeTimer_ invalidate];
			[fadeTimer_ release];
			fadeTimer_ = [[NSTimer scheduledTimerWithTimeInterval:FadeHiddingInterval
														   target:self
														 selector:@selector(timerHandler:)
														 userInfo:nil
														  repeats:YES] retain];
			break;
		case FadeTypeHidding:
		{
			CGFloat newAlpha = [[mediaPlayer_.view viewWithTag:kNavBarTag] alpha];
			newAlpha -= FadeHiddingInterval / FadeHiddingDuration;
			if(newAlpha <= 0)
			{
				[[mediaPlayer_.view viewWithTag:kNavBarTag] setAlpha:0];
				fadeType_ = FadeTypeNone;
				[fadeTimer_ invalidate];
				[fadeTimer_ release];
				fadeTimer_ = nil;
			}
			else
				[[mediaPlayer_.view viewWithTag:kNavBarTag] setAlpha:newAlpha];
		}
			break;
		default:
			break;
	}
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)dealloc
{
	NSLog(@"KTVideoPlayerController::dealloc");
	
	[fadeTimer_ invalidate];
	[fadeTimer_ release];
	
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[url_ release];
	[mediaPlayer_ release];
	
    [super dealloc];
}


@end
