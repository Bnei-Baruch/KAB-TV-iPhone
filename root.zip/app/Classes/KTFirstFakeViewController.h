//
//  KTFirstFakeViewController.h
//  KabTV
//
//  Copyright 2011 Leonid Reutov. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol KTFirstFakeViewControllerDelegate;

@interface KTFirstFakeViewController : UIViewController
{
	UIActivityIndicatorView* flower_;
	id<KTFirstFakeViewControllerDelegate> delegate_;
	
	NSMutableData* resultData_;
}

@property (nonatomic, assign) id<KTFirstFakeViewControllerDelegate> delegate;

- (void)startLoading;

@end

@protocol KTFirstFakeViewControllerDelegate

- (void)dataWasLoaded:(NSDictionary*)urls;

@end

