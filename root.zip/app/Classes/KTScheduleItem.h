//
//  KTScheduleItem.h
//  ICSParser
//
//  Created by Leonid on 11.03.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ical.h"
#import "icaltime.h"


@interface KTScheduleItem : NSObject
{
	NSString* uid_;
	NSString* status_;
	NSString* summary_;
	NSString* description_;
	NSDate* startDate_;
	NSDate* endDate_;
	
	NSString* keyDate_;
}

@property (nonatomic, readonly) NSString* uid;
@property (nonatomic, readonly) NSString* status;
@property (nonatomic, readonly) NSString* summary;
@property (nonatomic, readonly) NSString* description;
@property (nonatomic, readonly) NSDate* startDate;
@property (nonatomic, readonly) NSDate* endDate;
@property (nonatomic, readonly) NSString* keyDate;

+ (KTScheduleItem*)itemWithICalComponent:(icalcomponent*)iCalComponent;
+ (NSDate*)dateFromICalDate:(NSString*)strDate;
- (KTScheduleItem*)initWithICalComponent:(icalcomponent*)iCalComponent;

@end
