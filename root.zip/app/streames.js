{"vid_rus":"http://flash3.eu.kab.tv:1935/liverus/mobile.sdp/playlist.m3u8",
"vid_eng":"http://flash3.eu.kab.tv:1935/live/mobile.sdp/playlist.m3u8",
"vid_heb":"http://flash3.eu.kab.tv:1935/liveheb/mobile.sdp/playlist.m3u8",
"aud_rus":"http://kabbala.fm:8000/ices4.mp3",
"aud_eng":"http://kabbala.fm:8000/ices5.mp3",
"aud_heb":"http://kabbala.fm:8000/ices7.mp3"}